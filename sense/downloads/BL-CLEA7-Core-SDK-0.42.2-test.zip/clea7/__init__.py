"""BL CLEA7: original application runtime and Studio implementation."""
__version__ = '0.42.2'

