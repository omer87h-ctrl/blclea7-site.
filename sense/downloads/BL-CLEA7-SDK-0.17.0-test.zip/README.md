# BL CLEA7 public developer SDK 0.17.0-test — BIL Core2

TESTNA VERZIJA. Razvojni SDK za vlastite CLEA aplikacije, by Brzo i Lokalno.
Ovaj paket sadrži stvarni kompajler i provjereni interpreter; nije Studio niti
Windows/Android instalacijski paket. Ne sadrži privatni native build host,
model weights, korisničke dokumente, račune, API ključeve ili potpisne identitete.

Python 3.12+ i Node.js 22+ trebaju biti zasebno instalirani. Nema automatskog
preuzimanja ili prihvatanja licenci. Komande pokreni iz izdvojenog SDK direktorija:

```sh
python -m clea7 doctor
python -m clea7 bil features sdk/examples/bil/verified-application.bil
python -m clea7 bil check sdk/examples/bil/verified-application.bil
python -m clea7 bil run sdk/examples/bil/verified-application.bil
python -m clea7 bil package sdk/examples/bil/verified-application.bil --output verified.clea7
python -m clea7 validate verified.clea7
node sdk/verify_sense.cjs
```

Izlazne datoteke se ne prepisuju. Primjeri sadrže originalne izmišljene podatke.
Unsigned komande rade sa standardnim Python/Node bibliotekama. Za opcionu provjeru
potpisa treba zasebno instalirati kompatibilni `cryptography` paket prema postojećim
licencama i dokumentaciji; nije upakovan u ovaj SDK.

## Ugovor kompatibilnosti

Nove `guard` naredbe i Core2 tekstualne/kolekcijske operacije zahtijevaju Runtime
**0.17.0 ili noviji**. Stari programi zadržavaju stare minimalne verzije. Paket
navodi stvarni minimum; izvršni host ponovo provjerava izvor i IR.

Postojeća javna native izdanja Windows/Android 0.15 i web 0.16 nisu pretvorena u
0.17 ovim ZIP-om. Ovaj razvojni paket ne dokazuje novi APK, Windows GUI, fizički
uređaj ili produkcijski backend. Dodavanje Android cilja paketu nije Android build.

## Nezavisni razvoj i stvarni testovi

```sh
python -m clea7 validate sdk/examples/units.application.json
python -m clea7 package sdk/examples/units.application.json units.clea7 --targets browser,windows,android
python -m clea7 test units.clea7 --flow convert --state '{"kilometres":2.5}'
python -m clea7 test-suite sdk/examples/units.application.json sdk/examples/units.tests.json --mode light
```

Testovi izvršavaju provjereni Engine u odvojenom memorijskom kontekstu, bez Studija.
Native i mrežne mogućnosti nisu simulirano uspješne u SHADOW testu. Pogrešan
očekivani rezultat vraća neuspjeh.

## Sense primjer

`node sdk/verify_sense.cjs` izvršava lokalnu analizu originalnog testnog CV-a i
oglasa, izoliranu SHADOW potvrdu, provjeru neizmijenjenog izvornog nalaza i nacrt
iz potvrđenog izvora. Koristi isti stvarni BIL kompajler, Core2 operacije i Runtime.
Nema cloud modela, telemetrije, hardverskih dozvola ili prognoze odbijenice.
Detalji: `docs/SENSE-SDK.md`, `docs/BIL-CORE-2.md`, `docs/SDK-CORE-2.md`.

## Prava i porijeklo

`LICENSE.txt` i `MATERIALS-LICENSE.txt` sačuvani su byte-for-byte iz ranije javnog
SDK izdanja. Historijska oznaka 0.5 u naslovu licence nije nova open-source licenca
niti prenos vlasništva nad jezgrom. Postojeće dozvole i zasebne licence trećih
strana ostaju neizmijenjene. `NOTICE.txt` opisuje ovu razvojnu distribuciju.
Ne tvrdi se svjetsko prvenstvo, superiornost nad drugim AI sistemima ili odsustvo
svih grešaka. Starija dokumentacija zadržana je radi kompatibilnosti; za Core2
opseg mjerodavni su novi ugovori navedeni iznad.

`SDK-INVENTORY.json` sadrži SHA-256 i veličinu svakog drugog sadržanog fajla.
Integritet nije dokaz identiteta izdavača ili sigurnosti. Arhiv nije potpisan.
