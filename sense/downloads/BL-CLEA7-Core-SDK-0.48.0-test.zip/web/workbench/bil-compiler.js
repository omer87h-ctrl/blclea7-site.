'use strict';
/* BLclea Intent Language — original compiler, by Brzo i Lokalno.
   Input is data. No source is passed to eval, Function, a shell or a module URL. */
(function(scope){
const VERSION='bil/1', IR='bil.ir/1';
// Additive Core/2 features retain the old application and IR envelopes. Hosts
// must enforce the separately reported minimum runtime before accepting them.
const CORE2_OPERATIONS=Object.freeze(['text.normalize','text.includes','text.trim','text.codePointLength','text.sliceCodePoints','text.split','text.join','collections.contains','collections.slice','collections.concat','collections.unique']);
const CORE_FEATURES=Object.freeze({format:'bil.core.features/1',version:8,minimumRuntime:'0.47.0',operations:Object.freeze([...CORE2_OPERATIONS,'json.encode','json.decode','scene.body','scene.motion','scene.solid','scene.rebound','scene.step','scene.item','scene.replace','scene.overlap','scene.near','scene.sample']),statements:Object.freeze(['guard','derive','while','object.sentences','object.views','resource.image','resource.audio','depth.world'])});
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
const copy=x=>JSON.parse(JSON.stringify(x));
const safe=k=>typeof k==='string'&&/^[A-Za-z][A-Za-z0-9_]{0,63}$/.test(k)&&!['constructor','prototype','__proto__'].includes(k);
const hash=s=>{let n=2166136261;for(let i=0;i<s.length;i++)n=Math.imul(n^s.charCodeAt(i),16777619);return (n>>>0).toString(16);};

const PRESENTATION=Object.freeze({
 background:{kind:'color'},color:{kind:'color'},borderColor:{kind:'color'},gradientFrom:{kind:'color'},gradientTo:{kind:'color'},
 width:{kind:'size',min:0,max:4096},height:{kind:'size',min:0,max:4096},minWidth:{kind:'number',min:0,max:4096},maxWidth:{kind:'number',min:0,max:4096},
 padding:{kind:'number',min:0,max:128},gap:{kind:'number',min:0,max:128},radius:{kind:'number',min:0,max:256},borderWidth:{kind:'number',min:0,max:16},
 fontSize:{kind:'number',min:8,max:120},fontWeight:{kind:'number',min:100,max:900},opacity:{kind:'number',min:0,max:1},
 x:{kind:'number',min:-4096,max:4096},y:{kind:'number',min:-4096,max:4096},rotate:{kind:'number',min:-3600,max:3600},scale:{kind:'number',min:0,max:8},gradientAngle:{kind:'number',min:0,max:360},
 direction:{kind:'enum',values:['row','column']},align:{kind:'enum',values:['start','center','end','stretch']},justify:{kind:'enum',values:['start','center','end','space-between','space-around']},wrap:{kind:'enum',values:['wrap','nowrap']},
 position:{kind:'enum',values:['relative','absolute']},textAlign:{kind:'enum',values:['left','center','right']},font:{kind:'enum',values:['system','mono','serif']},shadow:{kind:'enum',values:['none','soft','lifted']}
});
const SHAPES=Object.freeze(['circle','square','diamond','triangle','ring']);
const GESTURES=Object.freeze(['tap','swipeLeft','swipeRight','press']);
const MOTIONS=Object.freeze(['none','fade','slide','move','scale']);
function checkAppearance(n,globals,handlers){
 if(n.style){for(const [key,value]of Object.entries(n.style)){
  const spec=PRESENTATION[key],at=n.styleLocs[key];if(!spec)fail('BIL_STYLE','Unknown visual property '+key+'.',at);
  if(value&&typeof value==='object'){
   if(Object.keys(value).join()!=='bind'||!['number','size'].includes(spec.kind)||globals.get(value.bind)?.type!=='Number')fail('BIL_STYLE','A numeric visual binding needs a declared Number.',at);
  }else if(spec.kind==='color'){if(typeof value!=='string'||!(/^(#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6})$/.test(value)||['transparent','inherit'].includes(value)))fail('BIL_STYLE','Use a hexadecimal colour, transparent or inherit.',at);}
  else if(spec.kind==='enum'){if(!spec.values.includes(value))fail('BIL_STYLE','Unsupported '+key+' value.',at);}
  else if(spec.kind==='size'&&['fill','auto'].includes(value)){}
  else if(typeof value!=='number'||!Number.isFinite(value)||value<spec.min||value>spec.max)fail('BIL_STYLE',key+' must be within '+spec.min+' and '+spec.max+'.',at);
 }if(own(n.style,'gradientFrom')!==own(n.style,'gradientTo'))fail('BIL_STYLE','A gradient requires both colours.',n.styleLoc);}
 if(n.motion&&(!MOTIONS.includes(n.motion.preset)||!Number.isInteger(n.motion.duration)||n.motion.duration<0||n.motion.duration>2000))fail('BIL_MOTION','Use a supported motion and a duration from 0 to 2000 milliseconds.',n.motionLoc);
 if(n.kind==='ui_mesh'&&(n.style||n.motion||n.gestures&&Object.keys(n.gestures).some(k=>k!=='tap')))fail('BIL_DEPTH','Mesh koristi3D transformacije i tap radnju;2D stilovi i druge geste nisu podržani.',n.loc);
 if(n.gestures){if(!['ui_card','ui_row','ui_heading','ui_text','ui_shape','ui_drawing','ui_sprite','ui_mesh'].includes(n.kind))fail('BIL_GESTURE','Gestures belong to non-input visual elements.',n.loc);
  for(const [name,handler]of Object.entries(n.gestures)){if(!GESTURES.includes(name)||!handlers.has(handler)||handlers.get(handler).params)fail('BIL_GESTURE','A gesture needs an existing ordinary event handler.',n.gestureLocs[name]);}
 }
}

class Diagnostic extends Error{
 constructor(code,message,at={line:1,column:1,start:0,end:0}){super(message);this.name='BILDiagnostic';this.code=code;this.location={line:at.line,column:at.column,start:at.start,end:at.end};}
}
function fail(code,message,at){throw new Diagnostic(code,message,at);}
function lex(source){
 if(typeof source!=='string'||source.length>131072)fail('BIL_LIMIT','BIL source must be at most 128 KiB.');
 const out=[];let i=0,line=1,column=1;
 const step=()=>{const c=source[i++];if(c==='\n'){line++;column=1;}else column++;return c;};
 const emit=(kind,value,start,l,c)=>{out.push({kind,value,start,end:i,line:l,column:c});if(out.length>24000)fail('BIL_LIMIT','Too many tokens.',out[out.length-1]);};
 while(i<source.length){const ch=source[i],start=i,l=line,c=column;
  if(ch===' '||ch==='\t'||ch==='\r'){step();continue;}
  if(ch==='\n'||ch===';'){step();emit('nl','\n',start,l,c);continue;}
  if(ch==='#'||ch==='/'&&source[i+1]==='/'){while(i<source.length&&source[i]!=='\n')step();continue;}
  if(ch==='"'){step();let closed=false;while(i<source.length){const x=step();if(x==='\n')fail('BIL_LEX','A text literal cannot cross a line.',{line:l,column:c,start,end:i});if(x==='\\'){if(i>=source.length)break;step();}else if(x==='"'){closed=true;break;}}
   if(!closed)fail('BIL_LEX','Unclosed text literal.',{line:l,column:c,start,end:i});let value;try{value=JSON.parse(source.slice(start,i));}catch{fail('BIL_LEX','Invalid text escape.',{line:l,column:c,start,end:i});}emit('string',value,start,l,c);continue;}
  if(/[0-9]/.test(ch)){while(i<source.length&&/[0-9]/.test(source[i]))step();if(source[i]==='.'&&/[0-9]/.test(source[i+1]||'')){step();while(/[0-9]/.test(source[i]||''))step();}const value=Number(source.slice(start,i));if(!Number.isFinite(value)||Math.abs(value)>1e15)fail('BIL_LEX','Number is outside the finite BIL range.',{line:l,column:c,start,end:i});emit('number',value,start,l,c);continue;}
  if(/[A-Za-z_]/.test(ch)){while(i<source.length&&/[A-Za-z0-9_]/.test(source[i]))step();emit('id',source.slice(start,i),start,l,c);continue;}
  const two=source.slice(i,i+2);if(['==','!=','<=','>=','->','&&','||'].includes(two)){step();step();emit('op',two,start,l,c);continue;}
  if('=+-*/%<>!?:.,()[]{}'.includes(ch)){step();emit('op',ch,start,l,c);continue;}
  fail('BIL_LEX','Unexpected character.',{line:l,column:c,start,end:start+1});
 }
 out.push({kind:'eof',value:'<eof>',start:i,end:i,line,column});return out;
}
const reserved=new Set('let const fn return if else repeat as for in record new import try catch raise show visualize move on change through runtime using within fallback range AI decide how to present explain last decision button runs true false null and or not Number Text Boolean List Record Error Void'.split(' '));
class Parser{
 constructor(source){this.source=source;this.tokens=lex(source);this.at=0;this.nodes=0;this.depth=0;this.blockDepth=0;this.typeDepth=0;this.path='global';this.ids=new Map();this.resources={};}
 peek(n=0){return this.tokens[Math.min(this.at+n,this.tokens.length-1)];}
 is(v){return this.peek().value===v;}
 take(v){if(v!==undefined&&!this.is(v))fail('BIL_PARSE','Expected '+v+'.',this.peek());return this.tokens[this.at++];}
 accept(v){if(this.is(v)){this.take();return true;}return false;}
 skip(){while(this.peek().kind==='nl')this.take();}
 name(){const t=this.take();if(t.kind!=='id'||!safe(t.value)||reserved.has(t.value))fail('BIL_NAME','Expected a safe, non-reserved identifier.',t);return t;}
 bindingName(){const owner=this.name();if(this.objectProjection&&this.accept('.'))return owner.value+'.'+this.name().value;return owner.value;}
 node(kind,from,fields={}){if(++this.nodes>8000)fail('BIL_LIMIT','Program exceeds the AST node budget.',from);return {kind,...fields,loc:{start:from.start,end:this.tokens[Math.max(0,this.at-1)].end,line:from.line,column:from.column}};}
 statementNode(kind,from,fields={}){const n=this.node(kind,from,fields),target=fields.name||fields.target?.name||fields.value?.name||'';const key=this.path+'/'+kind+'/'+target,num=(this.ids.get(key)||0)+1;this.ids.set(key,num);n.id='bil_'+hash(key+'/'+num);return n;}
 type(){if(++this.typeDepth>16)fail('BIL_LIMIT','Type nesting exceeds 16.',this.peek());const t=this.take();let result;if(['Number','Text','Boolean','Void','Error'].includes(t.value))result=t.value;else if(t.value==='List'){this.take('<');result={list:this.type()};this.take('>');}else if(safe(t.value)&&t.kind==='id')result={named:t.value};else fail('BIL_TYPE','Expected a type.',t);if(this.accept('?'))result={nullable:result};this.typeDepth--;return result;}
 block(path){if(++this.blockDepth>24)fail('BIL_LIMIT','Block nesting exceeds 24.',this.peek());this.take('{');const previous=this.path;this.path=path||previous+'/block';this.skip();const body=[];while(!this.is('}')){if(this.peek().kind==='eof')fail('BIL_PARSE','Unclosed block.',this.peek());body.push(this.statement());this.end();}this.take('}');this.path=previous;this.blockDepth--;return body;}
 end(){if(this.peek().kind==='nl'){this.skip();return;}if(!this.is('}')&&this.peek().kind!=='eof')fail('BIL_PARSE','Separate statements with a newline or semicolon.',this.peek());}
 resourceAhead(){return this.is('resurs')&&this.peek(1).kind==='id'&&this.peek(2).value==='vrsta';}
 resourceDeclaration(){const at=this.take('resurs'),id=this.name().value;this.take('vrsta');const type=this.take(),kind={slika:'image',zvuk:'audio'}[type.value];if(!kind||own(this.resources,id)||Object.keys(this.resources).length>=16)fail('BIL_RESOURCE','Resurs treba jedinstveno ime i vrstu slika ili zvuk; najviše16.',at);this.resources[id]={kind};this.take('.');this.skip();}
 resourceContract(){return Object.keys(this.resources).length?{resources:{format:'bil.resources/1',items:this.resources}}:{};}
 program(memo=null){this.skip();if(this.is('BIL')&&this.peek(1).kind==='string')return this.objectProgram();const hasResources=this.tokens.some((t,i)=>t.value==='resurs'&&this.tokens[i+1]?.kind==='id'&&this.tokens[i+2]?.value==='vrsta');if(memo&&!hasResources)return incrementalProgram(this,memo);const body=[];while(this.peek().kind!=='eof'){if(this.resourceAhead()){this.resourceDeclaration();continue;}body.push(this.statement());this.end();}return {kind:'program',format:VERSION,body,...this.resourceContract()};}
 // The sentence grammar is parsed into the same checked AST, never rewritten
 // into generated source. Locations always refer to the owner's original BIL.
 objectProgram(){
  const first=this.take('BIL'),title=this.textToken();this.take('.');this.skip();
  const objects=new Map(),actions=new Map(),offers=[],labels=[],symbols=new Set(),definitions=[],views=[];let startView=null;
  const named=()=>this.name(),end=()=>{this.take('.');this.skip();};
  const object=(name,at)=>{if(!objects.has(name)){if(objects.size>=24)fail('BIL_OBJECT','Najviše 24 objekta po programu.',at);objects.set(name,{name,loc:at,fields:new Map()});}return objects.get(name);};
  const symbol=(owner,field,at)=>{const key='BILObj_'+hash(owner+'.'+field);if(symbols.has(key))fail('BIL_OBJECT','Identitet polja se sudara s postojećim poljem.',at);symbols.add(key);return key;};
  const expression=(owner,min=0,depth=0)=>{
   if(depth>48)fail('BIL_LIMIT','Izraz prelazi dozvoljenu dubinu.',this.peek());
   const t=this.take();let node;
   if(t.kind==='number'||t.kind==='string'||['da','ne'].includes(t.value))node=this.node('literal',t,{value:t.kind==='id'?t.value==='da':t.value});
   else if(t.value==='('){node=expression(owner,0,depth+1);this.take(')');}
   else if(['minus','nije','-'].includes(t.value))node=this.node('unary',t,{operator:t.value==='nije'?'not':'-',value:expression(owner,7,depth+1)});
   else if(t.kind==='id'&&safe(t.value)&&!reserved.has(t.value)){
    let target=owner,field=t.value;if(this.is('.')&&this.peek(1).kind==='id'&&this.peek().line===this.peek(1).line){this.take();target=t.value;field=named().value;}
    node=this.node('object_ref',t,{owner:target,field});
   }else fail('BIL_OBJECT','Očekujem vrijednost, polje ili izraz BIL objekta.',t);
   const operators={ili:['or',1],i:['and',2],jednako:['==',3],razlicito:['!=',3],manje:['<',4],vece:['>',4],plus:['+',5],minus:['-',5],puta:['*',6],kroz:['/',6],ostatak:['%',6]};
   while(own(operators,this.peek().value)&&operators[this.peek().value][1]>=min){const [operator,priority]=operators[this.take().value],right=expression(owner,priority+1,depth+1);node=this.node('binary',t,{operator,left:node,right});}
   return node;
  };
  while(this.peek().kind!=='eof'){
   if(this.resourceAhead()){this.resourceDeclaration();continue;}
   if(this.is('pogled')&&this.peek(1).kind==='id'&&this.peek(2).kind==='string'){
    const at=this.take(),name=named().value,label=this.textToken();if(views.length>=16)fail('BIL_OBJECT','Najviše16 vlastitih pogleda.',at);
    this.objectProjection=true;let children;try{children=this.uiBlock('object-view/'+name);}finally{this.objectProjection=false;}
    const node=this.statementNode('screen',at,{name,label:label.value,labelLoc:label,children,childrenEnd:this.tokens[this.at-1].start,objectView:true});views.push(node);end();continue;
   }
   if(this.is('pocetak')&&this.peek(1).kind==='id'&&this.peek(2).value==='.'){
    const at=this.take();if(startView)fail('BIL_OBJECT','Početni pogled se navodi jednom.',at);startView={name:named().value,loc:at};end();continue;
   }
   const at=this.peek(),subject=named().value,verb=this.take();
   if(verb.value==='pamti'){
    const field=named();this.take('kao');const kind=this.take(),type={broj:'Number',tekst:'Text',logiku:'Boolean'}[kind.value];
    if(!type)fail('BIL_OBJECT','Tip polja je broj, tekst ili logiku.',kind);
    const value=expression(subject);if(value.kind!=='literal'&&!(value.kind==='unary'&&value.operator==='-'&&value.value.kind==='literal'&&typeof value.value.value==='number'))fail('BIL_OBJECT','Početno polje treba literalnu vrijednost.',value.loc);
    const owner=object(subject,at);if(owner.fields.has(field.value)||owner.fields.size>=32)fail('BIL_OBJECT','Polje je već definisano ili objekat ima previše polja.',field);
    const entry={owner:subject,name:field.value,symbol:symbol(subject,field.value,field),kind:'remember',annotation:type,value,loc:{...at,end:value.loc.end}};owner.fields.set(field.value,entry);definitions.push(entry);end();
   }else if(verb.value==='izvodi'){
    const field=named();this.take('iz');let value=expression(subject);
    if(this.accept(':')){
     const condition=value,cases=new Map();this.skip();
     for(let index=0;index<2;index++){
      const branch=this.take();if(!['da','ne'].includes(branch.value)||cases.has(branch.value))fail('BIL_OBJECT','Izbor treba tačno grane ne i da.',branch);
      this.take('daje');cases.set(branch.value,expression(subject));if(index===0){const separator=this.take();if(separator.kind!=='nl'||this.source[separator.start]!==';')fail('BIL_OBJECT','Prva grana izbora završava znakom ;.',separator);this.skip();}
     }
     value=this.node('choice',at,{condition,then:cases.get('da'),otherwise:cases.get('ne')});
    }
    const owner=object(subject,at);if(owner.fields.has(field.value)||owner.fields.size>=32)fail('BIL_OBJECT','Izvedeno polje je već definisano ili preveliko.',field);
    const entry={owner:subject,name:field.value,symbol:symbol(subject,field.value,field),kind:'derive',value,loc:{...at,end:value.loc.end}};owner.fields.set(field.value,entry);definitions.push(entry);end();
   }else if(verb.value==='nudi'){
    const label=this.textToken();this.take('kao');const action=named();offers.push({owner:subject,label:label.value,labelLoc:label,action:action.value,loc:{...at,end:action.end}});end();
   }else if(verb.value==='nad'){
    const owner=named().value;this.take('postavlja');const field=named();this.take('na');const value=expression(owner);
    if(!actions.has(subject))actions.set(subject,{name:subject,owner,loc:at,changes:[]});
    const action=actions.get(subject);if(action.owner!==owner)fail('BIL_OBJECT','Jedna imenovana radnja pripada jednom objektu.',at);
    action.changes.push({field:field.value,value,loc:{...at,end:value.loc.end}});end();
   }else if(verb.value==='prikazuje'){
    const field=named().value;this.take('kao');const label=this.textToken();labels.push({owner:subject,field,label:label.value,loc:label});end();
   }else fail('BIL_OBJECT','Rečenica koristi pamti, izvodi, nudi, nad ili prikazuje.',verb);
  }
  for(const name of objects.keys())if(symbols.has(name)||actions.has(name))fail('BIL_OBJECT','Objekat se sudara s imenovanom radnjom.',objects.get(name).loc);
  const resolve=value=>{if(!value||typeof value!=='object')return;
   if(value.kind==='object_ref'){const field=objects.get(value.owner)?.fields.get(value.field);if(!field)fail('BIL_OBJECT','Nepoznato polje '+value.owner+'.'+value.field+'.',value.loc);value.kind='name';value.name=field.symbol;delete value.owner;delete value.field;}
   for(const child of Object.values(value))if(child&&typeof child==='object')resolve(child);
  };
  for(const entry of definitions)resolve(entry.value);
  const body=[],built=new Set(),pending=new Set(),bySymbol=new Map(definitions.map(x=>[x.symbol,x]));
  const reads=value=>{const result=new Set(),walk=x=>{if(!x||typeof x!=='object')return;if(x.kind==='name')result.add(x.name);for(const child of Object.values(x))if(child&&typeof child==='object')walk(child);};walk(value);return [...result];};
  const emit=entry=>{
   if(built.has(entry.symbol))return;if(pending.has(entry.symbol))fail('BIL_OBJECT','Ciklus izvedenih polja nije dozvoljen.',entry.loc);pending.add(entry.symbol);
   for(const name of reads(entry.value))emit(bySymbol.get(name));
   this.path='object/'+entry.owner;const node=this.statementNode(entry.kind==='derive'?'derive':'declare',entry.loc,{name:entry.symbol,mutable:entry.kind!=='derive',annotation:entry.annotation||null,value:entry.value});node.loc={line:entry.loc.line,column:entry.loc.column,start:entry.loc.start,end:entry.loc.end};body.push(node);pending.delete(entry.symbol);built.add(entry.symbol);
  };
  for(const entry of definitions)emit(entry);
  for(const action of actions.values()){
   this.path='object/'+action.owner+'/action/'+action.name;const changes=[];
   for(const change of action.changes){const field=objects.get(action.owner)?.fields.get(change.field);if(!field||field.kind!=='remember')fail('BIL_OBJECT','Radnja mijenja samo postojeće zapamćeno polje.',change.loc);resolve(change.value);const target=this.node('name',change.loc,{name:field.symbol}),node=this.statementNode('assign',change.loc,{target,value:change.value});node.loc={line:change.loc.line,column:change.loc.column,start:change.loc.start,end:change.loc.end};changes.push(node);}
   const node=this.statementNode('handler',action.loc,{name:action.name,body:changes});node.loc={line:action.loc.line,column:action.loc.column,start:action.loc.start,end:changes.at(-1).loc.end};body.push(node);
  }
  for(const label of labels){const field=objects.get(label.owner)?.fields.get(label.field);if(!field)fail('BIL_OBJECT','Naziv prikaza zahtijeva postojeće polje.',label.loc);if(field.label)fail('BIL_OBJECT','Polje već ima naziv prikaza.',label.loc);field.label=label.label;field.labelLoc=label.loc;}
  const children=[],contract={format:'bil.objects/1',title:title.value,objects:[]};
  for(const owner of objects.values()){
   const fields={},components=[];this.path='object/'+owner.name;
   for(const field of owner.fields.values()){
    fields[field.name]=this.node('name',field.loc,{name:field.symbol});
    let node;
    if(field.kind==='remember'){const type=field.annotation==='Boolean'?'toggle':'input';node=this.statementNode('ui_'+type,field.loc,{name:field.symbol,label:field.label||field.name,labelLoc:field.labelLoc||null,required:false,multiline:false,range:null,options:null});}
    else{node=this.statementNode('intent',field.loc,{mode:'show',value:this.node('name',field.loc,{name:field.symbol}),ai:false,within:null,fallback:null,range:null});}
    node.loc={line:field.loc.line,column:field.loc.column,start:field.loc.start,end:field.loc.end};components.push(node);
   }
   const objectValue=this.node('recordValue',owner.loc,{name:null,fields}),aggregate=this.statementNode('derive',owner.loc,{name:owner.name,mutable:false,annotation:null,value:objectValue});aggregate.loc={line:owner.loc.line,column:owner.loc.column,start:owner.loc.start,end:owner.loc.end};body.push(aggregate);
   for(const offer of offers.filter(x=>x.owner===owner.name)){
    const action=actions.get(offer.action);if(!action||action.owner!==owner.name)fail('BIL_OBJECT','Ponuđena radnja mora pripadati istom objektu.',offer.loc);
    const node=this.statementNode('ui_button',offer.loc,{label:offer.label,labelLoc:offer.labelLoc,handler:offer.action,target:null,validate:false});node.loc={line:offer.loc.line,column:offer.loc.column,start:offer.loc.start,end:offer.loc.end};components.push(node);
   }
   const card=this.statementNode('ui_card',owner.loc,{label:owner.name,labelLoc:null,children:components,style:{background:'#14212e',color:'#edf3fa',padding:24,gap:16,radius:20,borderColor:'#31465b',borderWidth:1,width:'fill'},styleLocs:Object.fromEntries(['background','color','padding','gap','radius','borderColor','borderWidth','width'].map(k=>[k,owner.loc]))});card.loc={line:owner.loc.line,column:owner.loc.column,start:owner.loc.start,end:owner.loc.end};children.push(card);
   contract.objects.push({name:owner.name,fields:[...owner.fields.values()].map(x=>({name:x.name,symbol:x.symbol,derived:x.kind==='derive',label:x.label||x.name})),actions:[...actions.values()].filter(x=>x.owner===owner.name).map(x=>x.name)});
  }
  if(offers.some(x=>!objects.has(x.owner)))fail('BIL_OBJECT','Radnja je ponuđena nepostojećem objektu.',offers.find(x=>!objects.has(x.owner)).loc);
  if(views.length){
   contract.views=views.map(view=>view.name);
   const fieldBinding=(value,at)=>{const parts=value.split('.');if(parts.length!==2)fail('BIL_OBJECT','Pogled povezuje podatak kao objekat.polje.',at);const field=objects.get(parts[0])?.fields.get(parts[1]);if(!field)fail('BIL_OBJECT','Nepoznato polje pogleda '+value+'.',at);return field.symbol;};
   const link=nodes=>{for(const node of nodes){if(['ui_input','ui_toggle','ui_select','ui_image'].includes(node.kind))node.name=fieldBinding(node.name,node.loc);if(node.kind==='intent'&&node.value?.kind==='name')node.value.name=fieldBinding(node.value.name,node.loc);for(const value of Object.values(node.style||{}))if(value&&typeof value==='object'&&value.bind)value.bind=fieldBinding(value.bind,node.loc);if(node.camera)node.camera=node.camera.map(value=>fieldBinding(value,node.loc));if(node.kind==='ui_sprite'&&node.frame)node.frame=fieldBinding(node.frame,node.loc);for(const key of ['eye','aim','origin','extent','rotation'])if(node[key])node[key]=node[key].map(v=>v&&typeof v==='object'?{bind:fieldBinding(v.bind,node.loc)}:v);if(node.children)link(node.children);}};
   for(const view of views)link(view.children);body.push(...views);
   if(startView){this.path='object-start';body.push(this.statementNode('start',startView.loc,{name:startView.name}));}
  }else{
   if(startView)fail('BIL_OBJECT','Početak zahtijeva vlastiti pogled.',startView.loc);
   this.path='object-screen';const screen=this.statementNode('screen',first,{name:'objects',label:title.value,children});screen.loc={line:first.line,column:first.column,start:first.start,end:this.source.length};body.push(screen);
  }
  this.path='global';return {kind:'program',format:VERSION,body,objects:contract,...this.resourceContract()};
 }
 textToken(){const t=this.take();if(t.kind!=='string'||!t.value.trim()||t.value.length>200)fail('BIL_UI','Expected a nonempty label of at most 200 characters.',t);return t;}
 decorations(n){
 const used=new Set();
 while(['key','style','motion','gestures'].includes(this.peek().value)){
  const clause=this.take();if(used.has(clause.value))fail('BIL_UI','Duplicate visual clause.',clause);used.add(clause.value);
  if(clause.value==='key'){const key=this.name();if(key.value.length>48)fail('BIL_UI','A component key is limited to 48 characters.',key);n.key=key.value;n.id='bilui_'+key.value;}
  else if(clause.value==='style'){n.style={};n.styleLocs={};this.take('{');this.skip();while(!this.is('}')){const property=this.name();if(own(n.style,property.value))fail('BIL_STYLE','Duplicate visual property.',property);const negative=this.accept('-'),value=this.peek();let result;
    if(value.kind==='number'){this.take();result=negative?-value.value:value.value;}
    else if(negative)fail('BIL_STYLE','Only a Number can be negative.',value);
    else if(value.kind==='string'){this.take();result=value.value;}
    else result={bind:this.bindingName()};
    n.style[property.value]=result;n.styleLocs[property.value]={line:property.line,column:property.column,start:property.start,end:this.tokens[this.at-1].end};this.end();
   }this.take('}');n.styleLoc={line:clause.line,column:clause.column,start:clause.start,end:this.tokens[this.at-1].end};}
  else if(clause.value==='motion'){const preset=this.take(),duration=this.take();if(preset.kind!=='id'||duration.kind!=='number')fail('BIL_MOTION','Expected a motion name and milliseconds.',preset);n.motion={preset:preset.value,duration:duration.value};n.motionLoc={line:clause.line,column:clause.column,start:clause.start,end:duration.end};}
  else{n.gestures={};n.gestureLocs={};this.take('{');this.skip();while(!this.is('}')){const name=this.name();this.take('runs');const handler=this.name();if(own(n.gestures,name.value))fail('BIL_GESTURE','Duplicate gesture.',name);n.gestures[name.value]=handler.value;n.gestureLocs[name.value]={line:name.line,column:name.column,start:name.start,end:handler.end};this.end();}this.take('}');}
  n.loc.end=this.tokens[this.at-1].end;
 }return n;
 }
 triple(){this.take('[');const result=[];for(let i=0;i<3;i++){if(i)this.take(',');const sign=this.accept('-');if(this.peek().kind==='number')result.push((sign?-1:1)*this.take().value);else{if(sign)fail('BIL_DEPTH','A negative binding needs a BIL value.',this.peek());result.push({bind:this.bindingName()});}}this.take(']');return result;}
 uiBlock(path,depth=0){if(depth>8)fail('BIL_LIMIT','Screen layout nesting exceeds eight.',this.peek());this.take('{');const previous=this.path;this.path=path;this.skip();const body=[];while(!this.is('}')){const t=this.peek();let n;
  if(['heading','text'].includes(t.value)){const kind=this.take().value,label=this.textToken();n=this.statementNode('ui_'+kind,t,{label:label.value,labelLoc:label});}
  else if(this.accept('clock')){const label=this.textToken();this.take('every');const interval=this.take();if(interval.kind!=='number')fail('BIL_SCENE','Clock interval needs a Number literal.',interval);this.take('runs');const handler=this.name().value;n=this.statementNode('ui_clock',t,{label:label.value,interval:interval.value,handler});}
  else if(this.accept('pad')){const label=this.textToken(),directions={};for(const direction of ['left','right','up','down','release']){this.take(direction);directions[direction]=this.name().value;}n=this.statementNode('ui_pad',t,{label:label.value,directions});}
  else if(this.accept('world')){const label=this.textToken();this.take('camera');const eye=this.triple();this.take('looking');const aim=this.triple();let depthStrength=.45;if(this.accept('depth')){const n=this.take();if(n.kind!=='number')fail('BIL_DEPTH','Depth strength needs a Number literal.',n);depthStrength=n.value;}const children=this.uiBlock(path+'/world',depth+1);n=this.statementNode('ui_world',t,{label:label.value,labelLoc:label,eye,aim,depthStrength,children,childrenEnd:this.tokens[this.at-1].start});}
  else if(this.accept('mesh')){const label=this.textToken();this.take('geometry');const meshGeometry=this.textToken().value;let contour=null;if(this.accept('points')){this.take('[');contour=[];do{this.take('[');const a=this.take();this.take(',');const b=this.take();this.take(']');if(a.kind!=='number'||b.kind!=='number')fail('BIL_DEPTH','Contour points need literal numbers.',a);contour.push([a.value,b.value]);}while(this.accept(','));this.take(']');}this.take('at');const origin=this.triple();this.take('size');const extent=this.triple();this.take('rotation');const rotation=this.triple();this.take('surface');const surface=this.textToken().value;this.take('color');const tint=this.textToken().value;n=this.statementNode('ui_mesh',t,{label:label.value,labelLoc:label,meshGeometry,origin,extent,rotation,surface,tint,...(contour?{contour}:{})});}
  else if(this.accept('space')){const label=this.textToken();this.take('size');this.take('[');const width=this.take();this.take(',');const height=this.take();this.take(']');if(width.kind!=='number'||height.kind!=='number')fail('BIL_DRAW','Space size requires literal dimensions.',width);let camera=null;if(this.accept('camera')){this.take('[');camera=[this.bindingName()];this.take(',');camera.push(this.bindingName());this.take(',');camera.push(this.bindingName());this.take(']');}const children=this.uiBlock(path+'/space',depth+1);n=this.statementNode('ui_space',t,{...(camera?{camera}:{}),label:label.value,labelLoc:label,spaceSize:[width.value,height.value],children,childrenEnd:this.tokens[this.at-1].start});}
  else if(['row','card'].includes(t.value)){const kind=this.take().value;let label=null;if(this.peek().kind==='string')label=this.textToken();const children=this.uiBlock(path+'/'+kind,depth+1);n=this.statementNode('ui_'+kind,t,{label:label?.value||'',labelLoc:label,children,childrenEnd:this.tokens[this.at-1].start});}
  else if(['input','select','toggle'].includes(t.value)){const kind=this.take().value,name=this.bindingName();this.take('label');const label=this.textToken();n={name,label:label.value,labelLoc:label,required:false,multiline:false,range:null,options:null};const seen=new Set();while(['required','multiline','range','options'].includes(this.peek().value)){const clause=this.take().value;if(seen.has(clause))fail('BIL_UI','Duplicate field clause.',this.peek());seen.add(clause);if(clause==='required'||clause==='multiline')n[clause]=true;else{this.take('[');const values=[];if(!this.is(']'))do{const negative=this.accept('-'),value=this.take();if(value.kind!=='number'&&value.kind!=='string'||negative&&value.kind!=='number')fail('BIL_UI','Field options and bounds must be literal values.',value);values.push(negative?-value.value:value.value);}while(this.accept(','));this.take(']');n[clause]=values;}}n=this.statementNode('ui_'+kind,t,n);}
  else if(this.accept('shape')){const geometry=this.textToken();this.take('label');const label=this.textToken();n=this.statementNode('ui_shape',t,{geometry:geometry.value,label:label.value,labelLoc:label});}
  else if(this.accept('sprite')){const asset=this.name().value;this.take('label');const label=this.textToken();let grid=[1,1],frame=null;if(this.accept('frames')){this.take('[');grid=[this.take().value];this.take(',');grid.push(this.take().value);this.take(']');}if(this.accept('frame'))frame=this.bindingName();n=this.statementNode('ui_sprite',t,{asset,label:label.value,labelLoc:label,grid,frame});}
  else if(this.accept('sound')){const asset=this.name().value;this.take('label');const label=this.textToken();this.take('caption');const caption=this.textToken();n=this.statementNode('ui_sound',t,{asset,label:label.value,labelLoc:label,caption:caption.value});}
  else if(this.accept('drawing')){const label=this.textToken();this.take('points');this.take('[');const points=[];if(!this.is(']'))do{this.take('[');const x=this.take();this.take(',');const y=this.take();this.take(']');if(x.kind!=='number'||y.kind!=='number')fail('BIL_DRAW','Drawing points require literal coordinates.',x);points.push([x.value,y.value]);}while(this.accept(','));this.take(']');let role='object',closed=false,fill='transparent',ink='#ffac77',weight=2;if(this.accept('role'))role=this.name().value;if(this.accept('closed'))closed=true;if(this.accept('fill'))fill=this.textToken().value;if(this.accept('ink'))ink=this.textToken().value;if(this.accept('weight')){const value=this.take();if(value.kind!=='number')fail('BIL_DRAW','Drawing weight requires a Number.',value);weight=value.value;}n=this.statementNode('ui_drawing',t,{label:label.value,labelLoc:label,points,role,closed,fill,ink,weight});}
  else if(this.accept('image')){const name=this.name().value;this.take('label');const label=this.textToken();n=this.statementNode('ui_image',t,{name,label:label.value,labelLoc:label});}
  else if(this.accept('cards')){const name=this.name().value;this.take('label');const label=this.textToken();this.take('fields');this.take('[');const columns=[];if(!this.is(']'))do{const field=this.name().value;let label=field;if(this.accept(':'))label=this.textToken().value;columns.push({field,label});}while(this.accept(','));this.take(']');this.take('identity');const identity=this.name().value;this.take('select');const selection=this.name().value;let image=null;if(this.accept('image'))image=this.name().value;this.take('action');const actionLabel=this.textToken().value;this.take('runs');const handler=this.name().value;const empty=this.accept('empty')?this.textToken().value:'Još nema stavki.';n=this.statementNode('ui_cards',t,{name,label:label.value,columns,identity,selection,image,actionLabel,handler,empty});}
  else if(this.accept('table')){const name=this.name().value;this.take('columns');this.take('[');const columns=[];if(!this.is(']'))do{const field=this.name().value;let label=field;if(this.accept(':'))label=this.textToken().value;columns.push({field,label});}while(this.accept(','));this.take(']');this.take('select');n=this.statementNode('ui_table',t,{name,columns,selection:this.name().value});}
  else if(this.accept('button')){const label=this.textToken();let handler=null,target=null;if(this.accept('runs'))handler=this.name().value;else{this.take('opens');target=this.name().value;}const validate=this.accept('validate');n=this.statementNode('ui_button',t,{label:label.value,labelLoc:label,handler,target,validate});}
  else if(this.objectProjection&&(this.is('show')||this.is('visualize'))){const mode=this.take().value,at=this.peek(),name=this.bindingName();n=this.intent(t,mode,this.node('name',at,{name}),false);}
  else if(this.is('show')||this.is('visualize')){n=this.statement();}
  else fail('BIL_UI','Expected a screen component (heading, text, row, card, input, select, toggle, table, cards, button, show or visualize).',t);
  this.decorations(n);
  body.push(n);this.end();if(body.length>256)fail('BIL_LIMIT','A screen exceeds 256 components.',t);
 }this.take('}');this.path=previous;return body;}
 guardAhead(){let depth=0;for(let i=this.at+1;i<this.tokens.length;i++){const t=this.tokens[i];if(t.kind==='nl'||t.kind==='eof')return false;if(['(','[','{'].includes(t.value))depth++;else if([')',']','}'].includes(t.value)){if(depth===0)return false;depth--;}if(depth===0&&t.kind==='id'&&t.value==='else'&&this.tokens[i+1]?.value==='raise')return true;}return false;}
 whileAhead(){let depth=0;for(let i=this.at+1;i<this.tokens.length;i++){const t=this.tokens[i];if(t.kind==='nl'||t.kind==='eof')return false;if(depth===0&&t.value==='limit'&&this.tokens[i+2]?.value==='{')return true;if(['(','[','{'].includes(t.value))depth++;else if([')',']','}'].includes(t.value)){if(depth===0)return false;depth--;}}return false;}
 statement(){const t=this.peek();
  // guard remains contextual: existing identifiers/functions named guard remain legal.
  if(this.is('guard')&&this.guardAhead()){this.take();const condition=this.expression();this.take('else');const failure=this.take('raise'),code=this.take();if(code.kind!=='string'||!safe(code.value))fail('BIL_PARSE','Guard error code must be a safe text identifier.',code);this.take(',');return this.statementNode('guard',t,{condition,code:code.value,value:this.expression(),failureLoc:{line:failure.line,column:failure.column,start:failure.start,end:this.tokens[this.at-1].end}});}
  // derive is contextual, preserving old identifiers/functions named derive.
  if(this.is('derive')&&this.peek(1).kind==='id'&&['=',':'].includes(this.peek(2).value)){this.take();const name=this.name().value,annotation=this.accept(':')?this.type():null;this.take('=');return this.statementNode('derive',t,{name,mutable:false,annotation,value:this.expression()});}
  // New effect words remain contextual so old bil/1 identifiers stay legal.
  if(this.is('backend')&&this.peek(1).kind==='id'&&this.peek(2).value==='using'){this.take();const name=this.name().value;this.take('using');const adapter=this.take();if(adapter.kind!=='string')fail('BIL_REMOTE','A backend requires a versioned adapter string.',adapter);return this.statementNode('backend',t,{name,adapter:adapter.value});}
  if(this.is('request')&&this.peek(1).kind==='id'&&this.peek(2).value==='.'){this.take();const backend=this.name().value;this.take('.');const group=this.name().value;this.take('.');const operation=group+'.'+this.name().value;this.take('(');const args=[];if(!this.is(')'))do{args.push(this.expression());}while(this.accept(','));this.take(')');this.take('into');const name=this.name().value;this.take('catch');const fields={backend,operation,args,name,error:this.name().value};if(this.accept('then')){fields.completion={success:this.name().value};this.take('else');fields.completion.error=this.name().value;}return this.statementNode('request',t,fields);}
  if(this.is('subscribe')&&this.peek(1).kind==='id'&&this.peek(2).value==='from'){this.take();const subscription=this.name().value;this.take('from');const backend=this.name().value;this.take('.');const group=this.name().value;this.take('.');const operation=group+'.'+this.name().value;this.take('(');const args=[];if(!this.is(')'))do{args.push(this.expression());}while(this.accept(','));this.take(')');this.take('into');const name=this.name().value;this.take('catch');const error=this.name().value;this.take('every');const interval=this.take();if(interval.kind!=='number'||!Number.isInteger(interval.value)||interval.value<1000||interval.value>60000)fail('BIL_SUBSCRIPTION','Polling interval must be a literal 1000–60000 milliseconds.',interval);this.take('then');const completion={success:this.name().value};this.take('else');completion.error=this.name().value;this.take('stopped');completion.stopped=this.name().value;return this.statementNode('watch',t,{subscription,backend,operation,args,name,error,interval:interval.value,completion});}
  if(this.is('cancel')&&this.peek(1).kind==='id'){this.take();return this.statementNode('unwatch',t,{subscription:this.name().value});}
  // Contextual words keep existing bil/1 variables named screen/start/open legal.
  if(this.is('screen')&&this.peek(1).kind==='id'&&this.peek(2).kind==='string'){this.take();const name=this.name().value,label=this.textToken(),children=this.uiBlock('screen/'+name);return this.statementNode('screen',t,{name,label:label.value,labelLoc:label,children});}
  if((this.is('start')||this.is('open'))&&this.peek(1).kind==='id'){const kind=this.take().value;return this.statementNode(kind,t,{name:this.name().value});}
  if(this.is('let')&&this.peek(1).value==='AI'){this.take();this.take('AI');for(const w of ['decide','how','to','present'])this.take(w);const value=this.expression();return this.intent(t,'present',value,true);}
  if(this.is('let')||this.is('const')){const mutable=this.take().value==='let',name=this.name().value,annotation=this.accept(':')?this.type():null;this.take('=');return this.statementNode('declare',t,{name,mutable,annotation,value:this.expression()});}
  if(this.accept('import')){const name=this.name().value;return this.statementNode('import',t,{name});}
  if(this.accept('record')){const name=this.name().value;this.take('{');this.skip();const fields={};while(!this.is('}')){const key=this.name().value;this.take(':');if(own(fields,key))fail('BIL_TYPE','Duplicate record field.',t);fields[key]=this.type();if(!this.accept(',')){if(this.peek().kind==='nl')this.skip();else if(!this.is('}'))fail('BIL_PARSE','Expected comma or newline.',this.peek());}this.skip();}this.take('}');return this.statementNode('record',t,{name,fields});}
  if(this.accept('fn')){const name=this.name().value;this.take('(');const params=[];if(!this.is(')'))do{const p=this.name();this.take(':');params.push({name:p.value,type:this.type(),loc:p});}while(this.accept(','));this.take(')');this.take('->');const result=this.type(),body=this.block('fn/'+name);return this.statementNode('function',t,{name,params,result,body});}
  if(this.accept('on')){const name=this.name().value,fields={name};if(this.accept('(')){fields.params=[];if(!this.is(')'))do{const p=this.name();this.take(':');fields.params.push({name:p.value,type:this.type(),loc:p});}while(this.accept(','));this.take(')');}fields.body=this.block('handler/'+name);return this.statementNode('handler',t,fields);}
  if(this.accept('button')){const label=this.take();if(label.kind!=='string')fail('BIL_PARSE','Button label must be text.',label);this.take('runs');return this.statementNode('button',t,{label:label.value,name:this.name().value});}
  if(this.accept('if')){const condition=this.expression(),then=this.block();let otherwise=[];const mark=this.at;this.skip();if(this.accept('else'))otherwise=this.is('if')?[this.statement()]:this.block();else this.at=mark;return this.statementNode('if',t,{condition,then,otherwise});}
  // Bounded while is contextual: previous variables/functions named while or limit survive.
  if(this.is('while')&&this.whileAhead()){this.take();const condition=this.expression();this.take('limit');const bound=this.take();if(bound.kind!=='number'||!Number.isInteger(bound.value)||bound.value<1||bound.value>100)fail('BIL_LIMIT','while requires a literal limit from 1 to 100.',bound);return this.statementNode('while',t,{condition,limit:bound.value,body:this.block()});}
  if(this.accept('repeat')){const count=this.expression();this.take('as');const name=this.name().value;return this.statementNode('repeat',t,{name,count,body:this.block()});}
  if(this.accept('for')){const name=this.name().value;this.take('in');const value=this.expression();return this.statementNode('for',t,{name,value,body:this.block()});}
  if(this.accept('return'))return this.statementNode('return',t,{value:this.peek().kind==='nl'||this.is('}')?null:this.expression()});
  if(this.accept('raise')){const code=this.take();if(code.kind!=='string'||!safe(code.value))fail('BIL_PARSE','Error code must be a safe text identifier.',code);this.take(',');return this.statementNode('raise',t,{code:code.value,value:this.expression()});}
  if(this.accept('try')){const body=this.block();this.skip();this.take('catch');const name=this.name().value;if(this.accept(':'))this.take('Error');return this.statementNode('try',t,{name,body,recover:this.block()});}
  if(this.is('show')||this.is('visualize')){const mode=this.take().value;return this.intent(t,mode,this.expression(),false);}
  if(this.accept('move')){const target=this.name();for(const w of ['on','change','through','runtime'])this.take(w);return this.statementNode('move',t,{name:target.value});}
  if(this.accept('explain')){this.take('last');this.take('decision');return this.statementNode('explain',t);}
  const target=this.expression();if(this.accept('='))return this.statementNode('assign',t,{target,value:this.expression()});if(target.kind!=='call')fail('BIL_PARSE','Expected assignment, call or BIL statement.',t);return this.statementNode('expression',t,{value:target});
 }
 intent(t,mode,value,ai){if(value.kind!=='name')fail('BIL_INTENT','Reactive presentation requires a named value.',value.loc);const n={mode,value,ai,within:null,fallback:null,range:null};const seen=new Set();while(true){const mark=this.at;if(this.peek().kind==='nl'){this.skip();if(!['using','within','fallback','range'].includes(this.peek().value)){this.at=mark;break;}}const key=this.peek().value;if(!['using','within','fallback','range'].includes(key))break;this.take();if(seen.has(key))fail('BIL_INTENT','Duplicate intent clause '+key+'.',this.peek());seen.add(key);if(key==='using')this.take('runtime');if(key==='within'){this.take('[');n.within=[];if(!this.is(']'))do{n.within.push(this.name().value);}while(this.accept(','));this.take(']');}if(key==='fallback')n.fallback=this.name().value;if(key==='range'){this.take('[');n.range=[this.expression()];this.take(',');n.range.push(this.expression());this.take(']');}}
  if(ai&&(!n.within||!n.fallback))fail('BIL_INTENT','AI intent requires within and fallback.',t);return this.statementNode('intent',t,n);
 }
 expression(min=0){if(++this.depth>48)fail('BIL_LIMIT','Expression nesting exceeds 48.',this.peek());try{const t=this.take();let n;
  if(t.kind==='number'||t.kind==='string'||['true','false','null'].includes(t.value))n=this.node('literal',t,{value:t.kind==='number'||t.kind==='string'?t.value:t.value==='null'?null:t.value==='true'});
  else if(t.value==='('){n=this.expression();this.take(')');}
  else if(['-','+','!','not'].includes(t.value))n=this.node('unary',t,{operator:t.value,value:this.expression(7)});
  else if(t.value==='['){const items=[];if(!this.is(']'))do{items.push(this.expression());}while(this.accept(','));this.take(']');n=this.node('list',t,{items});}
  else if(t.value==='{'||t.value==='new'){let name=null;if(t.value==='new'){name=this.name().value;this.take('{');}const fields={};if(!this.is('}'))do{const key=this.name().value;this.take(':');if(own(fields,key))fail('BIL_TYPE','Duplicate record field.',t);fields[key]=this.expression();}while(this.accept(','));this.take('}');n=this.node('recordValue',t,{name,fields});}
  else if(t.kind==='id'&&safe(t.value)&&!reserved.has(t.value))n=this.node('name',t,{name:t.value});else fail('BIL_PARSE','Expected an expression.',t);
  const bp={'or':1,'||':1,'and':2,'&&':2,'==':3,'!=':3,'<':4,'>':4,'<=':4,'>=':4,'+':5,'-':5,'*':6,'/':6,'%':6};
  while(true){const op=this.peek().value;if(op==='('&&8>=min){this.take();const args=[];if(!this.is(')'))do{args.push(this.expression());}while(this.accept(','));this.take(')');n=this.node('call',t,{callee:n,args});continue;}
   if(op==='.'&&8>=min){this.take();n=this.node('field',t,{object:n,name:this.name().value});continue;}
   if(op==='['&&8>=min){this.take();const index=this.expression();this.take(']');n=this.node('index',t,{object:n,index});continue;}
   if(!own(bp,op)||bp[op]<min)break;this.take();const right=this.expression(bp[op]+1);n=this.node('binary',t,{operator:op,left:n,right});
  }return n;
 }finally{this.depth--;}}
}
// Project-local incremental reuse. The same lexer/parser/checker/lowerer remain
// authoritative; caches publish only after a complete successful compilation.
function relocate(value,from,to){
 const out=copy(value),offset=to.start-from.start,lines=to.line-from.line,columns=to.column-from.column;
 if(offset===0&&lines===0&&columns===0)return out;
 const visit=x=>{if(!x||typeof x!=='object')return;if(!Array.isArray(x)&&Number.isInteger(x.start)&&Number.isInteger(x.end)){x.start+=offset;x.end+=offset;if(Number.isInteger(x.line)){if(x.line===from.line&&Number.isInteger(x.column))x.column+=columns;x.line+=lines;}}for(const [key,child]of Object.entries(x)){if(key==='childrenEnd'&&Number.isInteger(child))x[key]=child+offset;else if(child&&typeof child==='object')visit(child);}};visit(out);return out;
}
const tokenKey=t=>t?JSON.stringify([t.kind,t.value]):'';
const lookahead=(tokens,at)=>JSON.stringify(tokens.slice(at,at+3).map(t=>[t.kind,t.value]));
function incrementalProgram(parser,memo){
 const old=new Map();for(const unit of memo.previous?.units||[]){if(!old.has(unit.key))old.set(unit.key,[]);old.get(unit.key).push(unit);}
 memo.stats.lexedTokens=parser.tokens.length;parser.skip();const body=[];
 while(parser.peek().kind!=='eof'){
  const at=parser.at,first=parser.peek(),key=tokenKey(first)+'|'+tokenKey(parser.peek(1))+'|'+tokenKey(parser.peek(2)),before=new Map(parser.ids),nodeCount=parser.nodes;
  const cached=(old.get(key)||[]).find(u=>{
   const end=at+u.tokens;if(end>parser.tokens.length||parser.tokens[end-1]?.end!==first.start+u.text.length||parser.source.slice(first.start,first.start+u.text.length)!==u.text||lookahead(parser.tokens,end)!==u.following)return false;
   return u.ids.every(([name,initial])=>(parser.ids.get(name)||0)===initial);
  });
  let node;
  if(cached){
   if(parser.nodes+cached.nodes>8000)fail('BIL_LIMIT','Program exceeds the AST node budget.',first);
   node=relocate(cached.node,cached.start,first);parser.at+=cached.tokens;parser.nodes+=cached.nodes;for(const [name,,after]of cached.ids)parser.ids.set(name,after);memo.stats.reusedUnits++;
  }else{node=parser.statement();memo.stats.parsedUnits++;}
  const ids=[...parser.ids].filter(([name,count])=>(before.get(name)||0)!==count).map(([name,count])=>[name,before.get(name)||0,count]);
  if(cached)memo.next.units.push(cached);else{const entry={key,text:parser.source.slice(first.start,parser.tokens[parser.at-1].end),tokens:parser.at-at,start:{start:first.start,end:first.end,line:first.line,column:first.column},following:lookahead(parser.tokens,parser.at),ids,nodes:parser.nodes-nodeCount,node:copy(node)};entry.bytes=JSON.stringify(entry).length*2;memo.next.units.push(entry);}
  body.push(node);parser.end();
 }
 return {kind:'program',format:VERSION,body};
}
function typeMemoKey(f,source,{globals,records,functions,imports,hasDerive,ast,collections}){
 return JSON.stringify([source.slice(f.loc.start,f.loc.end),[...globals],[...records],[...functions].map(([name,value])=>[name,value.params.map(p=>p.type),value.result]),[...imports],hasDerive,!!ast.extended,!!ast.live,!!ast.async,collections]);
}
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const display=t=>typeof t==='string'?t:JSON.stringify(t);
const isNull=t=>t==='Null';
const nullable=t=>t&&typeof t==='object'&&own(t,'nullable');
const errorType={record:{code:'Text',message:'Text'},name:'Error'};
const sceneBodyType={record:{id:'Text',x:'Number',y:'Number',width:'Number',height:'Number',vx:'Number',vy:'Number',mass:'Number',solid:'Boolean',bounce:'Number'},name:'SceneBody'};
const sceneList={list:sceneBodyType};
const builtin={scene:{body:[['Text','Number','Number','Number','Number','Number'],sceneBodyType],motion:[[sceneBodyType,'Number','Number'],sceneBodyType],solid:[[sceneBodyType,'Boolean'],sceneBodyType],rebound:[[sceneBodyType,'Number'],sceneBodyType],step:[[sceneList,'Number','Number','Number','Number'],sceneList],item:[[sceneList,'Text'],sceneBodyType],replace:[[sceneList,sceneBodyType],sceneList],overlap:[[sceneBodyType,sceneBodyType],'Boolean'],near:[[sceneBodyType,sceneBodyType,'Number'],'Boolean'],sample:[[{list:'Number'},{list:'Number'},'Number','Text'],'Number']},math:{abs:[['Number'],'Number'],min:[['Number','Number'],'Number'],max:[['Number','Number'],'Number'],clamp:[['Number','Number','Number'],'Number']},text:{upper:[['Text'],'Text'],lower:[['Text'],'Text'],length:[['Text'],'Number'],concat:[['Text','Text'],'Text'],normalize:[['Text'],'Text'],includes:[['Text','Text'],'Boolean'],trim:[['Text'],'Text'],codePointLength:[['Text'],'Number'],sliceCodePoints:[['Text','Number','Number'],'Text'],split:[['Text','Text'],{list:'Text'}],join:[[{list:'Text'},'Text'],'Text']},collections:{length:null,append:null,at:null,remove:null,replace:null,contains:null,slice:null,concat:null,unique:null},json:{encode:null,decode:null}};
function jsonType(type,allowUnknown=false){if(['Number','Text','Boolean','Null'].includes(type)||allowUnknown&&type==='Unknown')return true;if(type?.nullable)return jsonType(type.nullable,allowUnknown);if(type?.list)return jsonType(type.list,allowUnknown);return !!type?.record&&Object.entries(type.record).every(([key,value])=>safe(key)&&jsonType(value,allowUnknown));}
const RENDERERS=['counter','text','status','progress'];
const REMOTE_CONTRACTS=Object.freeze({'auth.session':Object.freeze({arguments:0,result:'session'}),'auth.register':Object.freeze({arguments:0,result:'session'}),'auth.signIn':Object.freeze({arguments:0,result:'session'}),'auth.signOut':Object.freeze({arguments:0,result:'Boolean'}),'document.get':Object.freeze({arguments:1,result:'document'}),'document.set':Object.freeze({arguments:2,result:'Boolean'}),'document.delete':Object.freeze({arguments:1,result:'Boolean'}),'query.list':Object.freeze({arguments:2,result:'list'}),'query.documents':Object.freeze({arguments:2,result:'documents'}),'document.add':Object.freeze({arguments:2,result:'created'})});
const remoteImageType={record:{path:'Text'},name:'RemoteImage'};
const NATIVE_ADAPTER='android.native/1';
const PRIVATE_ADAPTER='clea7500.private/1';
const PRIVATE_CONTRACTS=Object.freeze({'assistant.call':Object.freeze({arguments:1,input:'Text',result:'Text'})});
const SENSE_ADAPTER='sense.local/1';
const SENSE_CONTRACTS=Object.freeze({'speech.speak':Object.freeze({arguments:1,input:'Text',result:'Boolean'}),'speech.listen':Object.freeze({arguments:1,input:'Text',result:'Text',permission:'microphone'}),'speech.stop':Object.freeze({arguments:0,result:'Boolean'}),'document.docx':Object.freeze({arguments:1,input:'Text',result:'Boolean'}),'document.ocr':Object.freeze({arguments:1,input:'Text',result:'Text'}),'haptic.cue':Object.freeze({arguments:1,input:'Text',result:'Boolean',permission:'haptics'})});
const nativeMediaType={record:{handle:'Text',mime:'Text',width:'Number',height:'Number',bytes:'Number'},name:'NativeMedia'};
const IMAGE_CONTRACTS=Object.freeze({'image.choose':{arguments:0,result:nativeMediaType},'image.upload':{arguments:2,input:nativeMediaType,result:remoteImageType},'image.load':{arguments:1,input:remoteImageType,result:nativeMediaType},'image.remove':{arguments:1,input:remoteImageType,result:'Boolean'},'image.discard':{arguments:1,input:nativeMediaType,result:'Boolean'}});
const nativeLocationType={record:{latitude:'Number',longitude:'Number',accuracy:'Number',timestamp:'Number'},name:'NativeLocation'};
const nativeNotificationType={record:{title:'Text',body:'Text',id:'Number'},name:'NativeNotification'};
const nativeReceiptType={record:{posted:'Boolean',id:'Number'},name:'NativeReceipt'};
const NATIVE_CONTRACTS=Object.freeze({'camera.capture':{arguments:0,result:nativeMediaType,permission:'camera'},'media.pick':{arguments:0,result:nativeMediaType,permission:null},'media.list':{arguments:0,result:{list:nativeMediaType},permission:null},'media.inspect':{arguments:1,input:'Text',result:nativeMediaType,permission:null},'media.remove':{arguments:1,input:'Text',result:'Boolean',permission:null},'location.current':{arguments:0,result:nativeLocationType,permission:'location'},'notification.post':{arguments:1,input:nativeNotificationType,result:nativeReceiptType,permission:'notifications'}});
const remoteSessionType={record:{uid:'Text',email:'Text'},name:'RemoteSession'};
const remoteFailureType={record:{code:'Text',message:'Text',uncertain:'Boolean'},name:'RemoteFailure'};
const remoteDocumentType={record:{id:'Text',path:'Text'},name:'RemoteDocument'};
const remoteUpdateType={record:{subscriptionId:'Text',sourceId:'Text',backend:'Text',operation:'Text',sequence:'Number',kind:'Text'},name:'RemoteUpdate'};
const remoteFilterType={record:{field:'Text',op:'Text',kind:'Text',text:{nullable:'Text'},number:{nullable:'Number'},flag:{nullable:'Boolean'}},name:'RemoteFilter'};
const remoteQueryType={record:{where:{list:remoteFilterType},orderBy:'Text',descending:'Boolean',limit:'Number',offset:'Number'},name:'RemoteQuery'};
const remoteCompletionType={record:{requestId:'Text',sourceId:'Text',backend:'Text',operation:'Text'},name:'RemoteCompletion'};
function check(ast,memo=null){const stack=[[ast,0]];while(stack.length){const [value,depth]=stack.pop();if(depth>96)fail('BIL_LIMIT','AST nesting exceeds the checked compiler budget.',value?.loc);if(value&&typeof value==='object')for(const child of Object.values(value))if(child&&typeof child==='object')stack.push([child,depth+1]);}
 const hasDerive=ast.body.some(n=>n.kind==='derive');
 const watches=new Map(),cancellations=[],globals=new Map(),records=new Map(),functions=new Map(),handlers=new Map(),imports=new Set(),screens=new Map(),backends=new Map();let typeBudget=0;
 for(const n of ast.body)if(n.kind==='backend'){if(backends.has(n.name)||!['firebase.development/1','firebase.development/2','firebase.development/3','firebase.development/4',NATIVE_ADAPTER,SENSE_ADAPTER,PRIVATE_ADAPTER].includes(n.adapter)||backends.size>=4)fail('BIL_REMOTE','Declare at most four unique firebase.development/1 backends.',n.loc);backends.set(n.name,{adapter:n.adapter,operations:[]});ast.remote=true;ast.extended=true;if(['firebase.development/2','firebase.development/3','firebase.development/4',NATIVE_ADAPTER,SENSE_ADAPTER,PRIVATE_ADAPTER].includes(n.adapter))ast.live=true;}
 if(ast.body.some(n=>n.kind==='import'&&n.name==='scene'))records.set('SceneBody',copy(sceneBodyType.record));
 if(ast.body.some(n=>n.kind==='handler'&&n.params!==undefined))ast.async=true;
 if(ast.async&&!ast.remote)fail('BIL_EVENT','Typed completion handlers require a declared backend.');
 if([...backends.values()].some(b=>b.adapter==='firebase.development/4'))records.set('RemoteImage',copy(remoteImageType.record));
 if([...backends.values()].some(b=>b.adapter===NATIVE_ADAPTER||b.adapter==='firebase.development/4'))for(const type of [nativeMediaType,nativeLocationType,nativeNotificationType,nativeReceiptType])records.set(type.name,copy(type.record));
 if(ast.remote){records.set('RemoteSession',copy(remoteSessionType.record));records.set('RemoteFailure',copy(remoteFailureType.record));if(ast.async||ast.live)records.set('RemoteCompletion',copy(remoteCompletionType.record));if(ast.live){records.set('RemoteUpdate',copy(remoteUpdateType.record));records.set('RemoteDocument',copy(remoteDocumentType.record));records.set('RemoteFilter',copy(remoteFilterType.record));records.set('RemoteQuery',copy(remoteQueryType.record));}}
 for(const n of ast.body)if(n.kind==='screen'){if(screens.has(n.name))fail('BIL_UI','Duplicate screen identity.',n.loc);screens.set(n.name,n);ast.extended=true;}
  let elementCount=0,decorated=false,collections=false,collectionCount=0,drawingCount=0,drawingPoints=0;const inspectAppearance=items=>{for(const n of items){elementCount++;if(['ui_drawing','ui_space','ui_clock','ui_pad','ui_sprite','ui_sound','ui_world','ui_mesh'].includes(n.kind))collections=true;if(n.kind==='ui_drawing'&&(++drawingCount>64||(drawingPoints+=n.points.length)>4096))fail('BIL_LIMIT','Draw exceeds64 objects or4096 geometry points.',n.loc);if(n.kind==='ui_cards'){collections=true;if(++collectionCount>8)fail('BIL_LIMIT','At most eight card collections are supported per application.',n.loc);}if(n.style||n.motion||n.gestures||['ui_shape','ui_cards','ui_drawing'].includes(n.kind))decorated=true;if(n.children)inspectAppearance(n.children);}};for(const page of screens.values())inspectAppearance(page.children);
 const advancedUI=ast.extended&&(!!ast.objects||!!ast.resources||collections||decorated||elementCount>128||screens.size>32);
 if(screens.size>64)fail('BIL_LIMIT','At most 64 BIL screens are supported.');
 const guardType=t=>{let nodes=0;const walk=(v,d=0)=>{if(++nodes>2048||d>16)fail('BIL_LIMIT','Expanded type exceeds its structural budget.');if(v&&typeof v==='object')for(const [k,x]of Object.entries(v)){if(k==='record')for(const f of Object.values(x))walk(f,d+1);else if(k!=='name')walk(x,d+1);}};walk(t);typeBudget+=nodes;if(typeBudget>131072)fail('BIL_LIMIT','Compiler type expansion budget exceeded.');return t;};

 const resolve=(t,at=null)=>{if(typeof t==='string')return t==='Error'?copy(errorType):t;if(t?.list)return {list:resolve(t.list,at)};if(t?.nullable){const inner=resolve(t.nullable,at);if(inner==='Void')fail('BIL_TYPE','Void cannot be nullable.');return {nullable:inner};}if(t?.named){if(!records.has(t.named))fail('BIL_TYPE','Unknown record type '+t.named+'.',at||undefined);guardType({record:records.get(t.named)});return {record:copy(records.get(t.named)),name:t.named};}fail('BIL_TYPE','Invalid type.');};
 const fits=(target,value)=>same(target,value)||nullable(target)&&(isNull(value)||same(target.nullable,value));
 const expect=(actual,wanted,n)=>{if(!fits(wanted,actual))fail('BIL_TYPE','Expected '+display(wanted)+'; received '+display(actual)+'.',n.loc||n);};
 for(const n of ast.body)if(n.kind==='record'){if(records.has(n.name))fail('BIL_TYPE','Duplicate record '+n.name+'.',n.loc);const fields={};for(const [k,t]of Object.entries(n.fields)){fields[k]=resolve(t,n.loc);if(fields[k]==='Void')fail('BIL_TYPE','A field cannot have type Void.',n.loc);}guardType({record:fields});records.set(n.name,fields);}
 for(const n of ast.body){if(n.kind==='import'){if(!own(builtin,n.name))fail('BIL_IMPORT','Only bundled math, text, collections, json and scene modules are available.',n.loc);imports.add(n.name);}if(n.kind==='function'){if(functions.has(n.name)||imports.has(n.name))fail('BIL_TYPE','Duplicate function.',n.loc);n.params=n.params.map(p=>({...p,type:resolve(p.type,p.loc)}));n.result=resolve(n.result,n.loc);if(n.params.some(p=>p.type==='Void'))fail('BIL_TYPE','Parameters cannot have type Void.',n.loc);functions.set(n.name,n);}if(n.kind==='handler'){if(n.name==='main'||n.name.length>60)fail('BIL_NAME','Handler name is reserved or exceeds 60 characters.',n.loc);if(handlers.has(n.name))fail('BIL_TYPE','Duplicate event handler.',n.loc);if(n.params!==undefined){if(n.params.length!==2)fail('BIL_EVENT','A completion handler takes a typed value and RemoteCompletion context.',n.loc);n.params=n.params.map(p=>({...p,type:resolve(p.type,p.loc)}));if(new Set(n.params.map(p=>p.name)).size!==2||n.params.some(p=>p.type==='Void')||!same(n.params[1].type,remoteCompletionType)&&!(ast.live&&same(n.params[1].type,remoteUpdateType)))fail('BIL_EVENT','Distinct typed parameters and RemoteCompletion context are required.',n.loc);}handlers.set(n.name,n);}}
 function find(env,name,n){for(let e=env;e;e=e.parent){if(e.refinements?.has(name))return e.refinements.get(name);if(e.symbols.has(name))return e.symbols.get(name);}fail('BIL_NAME','Unknown value '+name+'.',n.loc);}
 function invalidateGuard(env,name){for(let e=env;e;e=e.parent)e.refinements?.delete(name);}
 function invalidateRemoteError(env,name){for(let e=env;e;e=e.parent){const guarded=e.refinements?.get(name);if(guarded?.globalOwner===true)e.refinements.delete(name);const narrowed=e.symbols.get(name);if(narrowed?.globalOwner===true&&narrowed.original)narrowed.type=copy(narrowed.original);}}
 function expression(n,env){let t;
  if(n.kind==='choice'){expect(expression(n.condition,env),'Boolean',n);const yes=expression(n.then,env),no=expression(n.otherwise,env);if(!same(yes,no))fail('BIL_TYPE','Obje grane izvedenog izbora moraju imati isti tip.',n.loc);guardType(yes);n.type=copy(yes);return yes;}
  switch(n.kind){case'literal':t=n.value===null?'Null':typeof n.value==='number'?'Number':typeof n.value==='string'?'Text':'Boolean';break;
   case'name':{const symbol=find(env,n.name,n);t=symbol.type;if(hasDerive&&(globals.get(n.name)===symbol||symbol.globalOwner===true))n.derivationGlobal=true;break;}
   case'list':{const ts=n.items.map(x=>expression(x,env));if(!ts.length)t={list:'Unknown'};else{if(ts.some(x=>!same(x,ts[0])))fail('BIL_TYPE','List items must share one type.',n.loc);t={list:ts[0]};}break;}
   case'recordValue':{const fields={};for(const [k,x]of Object.entries(n.fields))fields[k]=expression(x,env);if(n.name){const wanted=resolve({named:n.name},n.loc);if(Object.keys(fields).sort().join('|')!==Object.keys(wanted.record).sort().join('|'))fail('BIL_TYPE','Record fields do not match '+n.name+'.',n.loc);for(const k of Object.keys(fields))expect(fields[k],wanted.record[k],n);t=wanted;}else t={record:fields};break;}
   case'field':{const base=expression(n.object,env);if(nullable(base))fail('BIL_NULL','Check the value against null before accessing a field.',n.loc);if(!base?.record||!own(base.record,n.name))fail('BIL_TYPE','Unknown record field '+n.name+'.',n.loc);t=base.record[n.name];break;}
   case'index':{const base=expression(n.object,env);expect(expression(n.index,env),'Number',n);if(!base?.list)fail('BIL_TYPE','Indexing requires a List.',n.loc);t=base.list;break;}
   case'unary':t=expression(n.value,env);expect(t,['!','not'].includes(n.operator)?'Boolean':'Number',n);break;
   case'binary':{const a=expression(n.left,env),b=expression(n.right,env),op=n.operator;if(['==','!='].includes(op)){if(!fits(a,b)&&!fits(b,a))fail('BIL_TYPE','Equality requires compatible types.',n.loc);t='Boolean';}else if(['and','or','&&','||'].includes(op)){expect(a,'Boolean',n);expect(b,'Boolean',n);t='Boolean';}else if(['<','>','<=','>='].includes(op)){expect(a,'Number',n);expect(b,'Number',n);t='Boolean';}else if(op==='+'&&a==='Text'&&b==='Text')t='Text';else{expect(a,'Number',n);expect(b,'Number',n);t='Number';}break;}
   case'call':{const args=n.args.map(x=>expression(x,env));if(n.callee.kind==='name'){const f=functions.get(n.callee.name);if(!f)fail('BIL_CALL','Unknown BIL function.',n.loc);if(args.length!==f.params.length)fail('BIL_CALL','Wrong argument count.',n.loc);args.forEach((t,i)=>expect(t,f.params[i].type,n));t=f.result;n.call=f.name;}else if(n.callee.kind==='field'&&n.callee.object.kind==='name'){const module=n.callee.object.name,name=n.callee.name;if(!imports.has(module)||!own(builtin[module],name))fail('BIL_IMPORT','Operation is not in an imported bundled module.',n.loc);n.call=module+'.'+name;if(module==='json'){if(name==='encode'){if(args.length!==1)fail('BIL_CALL','json.encode expects one data value.',n.loc);if(!jsonType(args[0],true))fail('BIL_TYPE','json.encode accepts only supported BIL data.',n.loc);t='Text';}else{if(args.length!==2)fail('BIL_CALL','json.decode expects Text and a typed exemplar.',n.loc);expect(args[0],'Text',n);if(args[1]==='Null'||!jsonType(args[1]))fail('BIL_TYPE','json.decode requires a concrete data schema from its exemplar.',n.loc);t=copy(args[1]);}}else if(module==='collections'){if(!args[0]?.list)fail('BIL_TYPE','Collection operation requires a List.',n.loc);
    if(['contains','slice','concat','unique'].includes(name)){
     const count={contains:2,slice:3,concat:2,unique:1}[name];if(args.length!==count)fail('BIL_CALL','Wrong collection argument count.',n.loc);
     if(name==='concat'&&!args[1]?.list)fail('BIL_TYPE','concat requires two Lists.',n.loc);
     if(args[0].list==='Unknown'){
      const item=name==='contains'?args[1]:name==='concat'?args[1].list:null;
      if(!item||item==='Unknown'||item==='Null'||item==='Void')fail('BIL_TYPE','An empty collection needs a known item type.',n.loc);
      args[0]={list:copy(item)};n.args[0].type=copy(args[0]);
     }
     if(name==='contains'){expect(args[1],args[0].list,n);t='Boolean';}
     else if(name==='slice'){expect(args[1],'Number',n);expect(args[2],'Number',n);t=args[0];}
     else if(name==='concat'){if(args[1].list==='Unknown'&&n.args[1].kind==='list'&&!n.args[1].items.length){args[1]=copy(args[0]);n.args[1].type=copy(args[0]);}expect(args[1],args[0],n);t=args[0];}
     else t=args[0];
    }else if(name==='length'){if(args.length!==1)fail('BIL_CALL','length expects one argument.',n.loc);t='Number';}else{if(args.length!==(name==='replace'?3:2))fail('BIL_CALL','Wrong collection argument count.',n.loc);if(name==='append'){expect(args[1],args[0].list,n);t=args[0];}else{expect(args[1],'Number',n);if(name==='replace')expect(args[2],args[0].list,n);t=name==='at'?args[0].list:args[0];if(name==='replace'||name==='remove')ast.extended=true;}}}else{const signature=builtin[module][name];if(args.length!==signature[0].length)fail('BIL_CALL','Wrong bundled argument count.',n.loc);args.forEach((t,i)=>{const wanted=signature[0][i];if(wanted?.list&&t?.list==='Unknown'&&n.args[i].kind==='list'&&!n.args[i].items.length){n.args[i].type=copy(wanted);args[i]=copy(wanted);}else expect(t,wanted,n);});t=signature[1];}}else fail('BIL_CALL','Only named BIL functions and bundled operations may be called.',n.loc);break;}
   default:fail('BIL_TYPE','Unknown expression.',n.loc);
  }guardType(t);n.type=copy(t);return t;
 }
 const child=env=>({symbols:new Map(),parent:env,global:false});
 function narrowed(env,condition,truth){const e=child(env);if(condition.kind==='binary'&&['==','!='].includes(condition.operator)){const name=condition.left.kind==='name'&&condition.right.kind==='literal'&&condition.right.value===null?condition.left.name:condition.right.kind==='name'&&condition.left.kind==='literal'&&condition.left.value===null?condition.right.name:null;if(name){const old=find(env,name,condition);if(nullable(old.type)){const present=condition.operator==='!='?truth:!truth;e.symbols.set(name,{...old,type:present?old.type.nullable:'Null',original:old.type,globalOwner:old.globalOwner===true||globals.get(name)===old});}}}return e;}
 function statements(body,env,result=null,top=false,context='main'){env={...env,refinements:new Map()};let returned=false;for(const n of body){if(returned)fail('BIL_FLOW','Unreachable statement after return.',n.loc);
  if(['record','function','handler','import','button','screen','start','backend'].includes(n.kind)){if(!top)fail('BIL_SCOPE','Declarations of modules, records, functions, handlers and buttons belong at top level.',n.loc);if(n.kind==='button'&&(!handlers.has(n.name)||handlers.get(n.name).params))fail('BIL_NAME','Button requires a declared handler without completion parameters.',n.loc);continue;}
  if(n.kind==='derive'&&(!top||!env.global))fail('BIL_DERIVE','Derived values belong at the top level.',n.loc);
  if(n.kind==='declare'||n.kind==='derive'||n.kind==='assign'){
   const value=expression(n.value,env),name=(n.kind==='declare'||n.kind==='derive')?n.name:n.target.kind==='name'?n.target.name:null;
   let previous=null;if(name){for(let e=env;e;e=e.parent)if(e.symbols.has(name)){previous=e.symbols.get(name);break;}}
   if((n.kind==='declare'||n.kind==='derive')&&env.symbols.has(name))fail('BIL_NAME','Value is already declared in this scope.',n.loc);
   if(n.kind==='declare'||n.kind==='derive'||name&&!previous){if(!safe(name)||imports.has(name)||functions.has(name)||handlers.has(name)||backends.has(name))fail('BIL_NAME','Name conflicts with a callable or module.',n.loc);let type=n.annotation?resolve(n.annotation,n.loc):value;if(isNull(type)||type?.list==='Unknown'&&!n.annotation)fail('BIL_TYPE','Null and empty lists require an explicit type.',n.loc);if(type==='Void')fail('BIL_TYPE','Cannot store Void.',n.loc);if(value?.list==='Unknown'&&type?.list)n.value.type=copy(type);else expect(value,type,n);const symbol={type,mutable:n.kind==='assign'||n.mutable};env.symbols.set(name,symbol);env.refinements.delete(name);n.name=name;n.declaration=true;n.global=env.global;n.declaredType=copy(type);n.mutable=symbol.mutable;if(env.global)globals.set(name,symbol);
   }else{const root=x=>x.kind==='name'?x.name:x.object?root(x.object):null;const rootName=root(n.target);if(!rootName)fail('BIL_TYPE','Assignment requires a variable, record field or list index.',n.loc);const sym=find(env,rootName,n);if(!sym.mutable)fail('BIL_CONST','Cannot modify a constant.',n.loc);const wanted=n.target.kind==='name'&&sym.original?sym.original:expression(n.target,env);if((ast.live||collections)&&value?.list==='Unknown'&&wanted?.list&&n.value.kind==='list'&&!n.value.items.length)n.value.type=copy(wanted);else expect(value,wanted,n);if(n.target.kind==='name'&&sym.original)sym.type=copy(n.value.type);n.global=globals.get(rootName)===sym||sym.globalOwner===true;if(result!==null&&n.global)fail('BIL_EFFECT','Functions are pure; update application values in an event handler.',n.loc);invalidateGuard(env,rootName);}
   continue;
  }
  if(n.kind==='guard'){
   expect(expression(n.condition,env),'Boolean',n);expect(expression(n.value,narrowed(env,n.condition,false)),'Text',n);
   // The success path refines only direct nullable-name comparisons. Every write
   // conservatively invalidates guard knowledge, including writes in a branch.
   const refined=narrowed(env,n.condition,true);for(const [name,symbol]of refined.symbols)env.refinements.set(name,symbol);
   continue;
  }
  if(n.kind==='if'){expect(expression(n.condition,env),'Boolean',n);const a=statements(n.then,narrowed(env,n.condition,true),result,false,context),b=statements(n.otherwise,narrowed(env,n.condition,false),result,false,context);returned=a&&b;continue;}
  if(n.kind==='while'){expect(expression(n.condition,env),'Boolean',n);statements(n.body,child(env),result,false,context);continue;}
  if(n.kind==='repeat'||n.kind==='for'){const t=expression(n.kind==='repeat'?n.count:n.value,env);if(n.kind==='repeat')expect(t,'Number',n);else if(!t?.list)fail('BIL_TYPE','for requires a List.',n.loc);const e=child(env);e.symbols.set(n.name,{type:n.kind==='repeat'?'Number':t.list,mutable:false});statements(n.body,e,result,false,context);continue;}
  if(n.kind==='return'){if(result===null)fail('BIL_FLOW','return is only valid inside a function.',n.loc);expect(n.value?expression(n.value,env):'Void',result,n);returned=true;continue;}
  if(n.kind==='raise'){expect(expression(n.value,env),'Text',n);continue;}
  if(n.kind==='try'){const a=statements(n.body,child(env),result,false,context),e=child(env);e.symbols.set(n.name,{type:copy(errorType),mutable:false});const b=statements(n.recover,e,result,false,context);returned=a&&b;continue;}
  if(n.kind==='request'||n.kind==='watch'){
   if(context!=='handler'||result!==null)fail('BIL_EFFECT','Remote requests belong only in event handlers, never main or pure functions.',n.loc);
   const backend=backends.get(n.backend),native=backend?.adapter===NATIVE_ADAPTER,sense=backend?.adapter===SENSE_ADAPTER,image=n.operation.startsWith('image.'),contracts=backend?.adapter===PRIVATE_ADAPTER?PRIVATE_CONTRACTS:sense?SENSE_CONTRACTS:native?NATIVE_CONTRACTS:image&&backend?.adapter==='firebase.development/4'?IMAGE_CONTRACTS:REMOTE_CONTRACTS,contract=own(contracts,n.operation)?contracts[n.operation]:null;if(!backend||!contract||(['query.list','query.documents','document.add'].includes(n.operation)||n.kind==='watch')&&!['firebase.development/2','firebase.development/3','firebase.development/4'].includes(backend.adapter)||n.operation==='query.documents'&&!['firebase.development/3','firebase.development/4'].includes(backend?.adapter))fail('BIL_REMOTE','Request requires a declared backend and registered operation.',n.loc);
   if(n.args.length!==contract.arguments)fail('BIL_REMOTE','Remote operation has an invalid argument count; credentials are entered through the trusted host.',n.loc);
   if(native&&n.kind==='watch')fail('BIL_NATIVE','Native operations cannot be polled or subscribed.',n.loc);const types=n.args.map(x=>expression(x,env));if(image){if(n.kind==='watch')fail('BIL_REMOTE','Image operations cannot be subscriptions.',n.loc);if(types.length)expect(types[0],contract.input,n);if(n.operation==='image.upload')expect(types[1],'Boolean',n);}else if(native&&types.length)expect(types[0],contract.input,n);else if(types.length)expect(types[0],'Text',n);if(['query.list','query.documents'].includes(n.operation))expect(types[1],remoteQueryType,n);if(n.kind==='watch'&&!['document.get','query.list','query.documents'].includes(n.operation))fail('BIL_SUBSCRIPTION','Subscriptions permit only registered read operations.',n.loc);if(['document.set','document.add'].includes(n.operation)&&!types[1]?.record)fail('BIL_TYPE','Remote document data must be a typed Record; List values may be record fields.',n.loc);
   const target=globals.get(n.name),error=globals.get(n.error);if(!target?.mutable||!error?.mutable||n.name===n.error)fail('BIL_REMOTE','Remote result and error require distinct mutable application values.',n.loc);
   if(!nullable(error.type)||!same(error.type.nullable.record,remoteFailureType.record))fail('BIL_TYPE','Remote error target must have nullable RemoteFailure type.',n.loc);
   const valueType=nullable(target.type)?target.type.nullable:target.type;if((native||image||sense||backend?.adapter===PRIVATE_ADAPTER)&&!same(valueType,contract.result))fail('BIL_NATIVE','Native result target does not match the registered operation.',n.loc);
   if(contract.result==='session'&&(!same(valueType?.record,remoteSessionType.record)||n.operation==='auth.session'&&!nullable(target.type)))fail('BIL_TYPE','Authentication requires RemoteSession (nullable for session lookup).',n.loc);
   if(contract.result==='document'&&(!nullable(target.type)||!valueType?.record))fail('BIL_TYPE','Document lookup requires a nullable typed Record.',n.loc);
   if(contract.result==='created'&&!same(target.type,remoteDocumentType)&&!same(target.type,{nullable:remoteDocumentType}))fail('BIL_TYPE','Creation requires RemoteDocument or RemoteDocument?.',n.loc);if(contract.result==='documents'&&(!target.type?.list?.record||Object.keys(target.type.list.record).sort().join('|')!=='id|path|value'||target.type.list.record.id!=='Text'||target.type.list.record.path!=='Text'||!target.type.list.record.value?.record))fail('BIL_TYPE','Identified query results require List<Record { id: Text, path: Text, value: YourRecord }>.',n.loc);if(contract.result==='list'&&!target.type?.list?.record)fail('BIL_TYPE','A query result must be List<Record>.',n.loc);if(contract.result==='Boolean'&&target.type!=='Boolean')fail('BIL_TYPE','Remote operation requires a Boolean result target.',n.loc);
   n.resultType=copy(target.type);
   if(n.completion){if(!ast.async)fail('BIL_EVENT','Declare typed success and failure handlers.',n.loc);for(const [kind,type]of [['success',target.type],['error',remoteFailureType],...(n.kind==='watch'?[['stopped','Boolean']]:[])]){const handler=handlers.get(n.completion[kind]);if(!handler?.params||!same(handler.params[0].type,type)||!same(handler.params[1].type,n.kind==='watch'?remoteUpdateType:remoteCompletionType))fail('BIL_EVENT','Completion '+kind+' handler has an incompatible value parameter.',n.loc);handler.completionUsed=true;}}
   if(n.kind==='watch'){if(watches.has(n.subscription)||watches.size>=4)fail('BIL_SUBSCRIPTION','Declare at most four subscriptions with unique names.',n.loc);watches.set(n.subscription,n);const op='observe.'+n.operation;if(!backend.operations.includes(op))backend.operations.push(op);}
   // Staging REQUEST/WATCH synchronously clears the error slot. A successful
   // guard before this effect must not make that now-null value look present.
   invalidateRemoteError(env,n.error);
   if(!backend.operations.includes(n.operation))backend.operations.push(n.operation);continue;
  }
  if(n.kind==='unwatch'){if(context!=='handler'||!ast.live)fail('BIL_SUBSCRIPTION','Cancellation requires an event and a version2 backend.',n.loc);cancellations.push(n);continue;}
  if(n.kind==='expression'){expression(n.value,env);continue;}
  if(n.kind==='intent'){if(result!==null||!globals.has(n.value.name))fail('BIL_INTENT','A view binds an application value; presentation is not allowed inside a pure function.',n.loc);const type=expression(n.value,env);if(type==='Void'||isNull(type)||nullable(type))fail('BIL_INTENT','Presentation requires a non-null value; guard nullable values first.',n.loc);if(n.within&&(!n.within.length||n.within.length>4||new Set(n.within).size!==n.within.length||n.within.some(k=>!RENDERERS.includes(k))))fail('BIL_INTENT','within must name registered presentation operations.',n.loc);if(n.fallback&&(!RENDERERS.includes(n.fallback)||n.within&&!n.within.includes(n.fallback)))fail('BIL_INTENT','Fallback must be a permitted renderer.',n.loc);if(n.range){expect(type,'Number',n);n.range.forEach(x=>expect(expression(x,env),'Number',n));}if(n.fallback&&n.fallback!=='text'&&({counter:'Number',progress:'Number',status:'Boolean'})[n.fallback]!==type)fail('BIL_INTENT','Fallback input type is incompatible.',n.loc);if(n.fallback==='progress'&&!n.range)fail('BIL_INTENT','Progress fallback requires declared bounds.',n.loc);if(n.ai&&!n.fallback)fail('BIL_INTENT','AI needs a declared fallback.',n.loc);n.inputType=copy(type);continue;}
  if(n.kind==='move'){if(result!==null||!globals.has(n.name))fail('BIL_EFFECT','Motion requires an application value outside a pure function.',n.loc);expect(find(env,n.name,n).type,'Number',n);continue;}
  if(n.kind==='open'){if(result!==null||!screens.has(n.name))fail('BIL_UI','Navigation requires a declared screen outside a pure function.',n.loc);ast.extended=true;continue;}
  if(n.kind==='explain'){if(result!==null)fail('BIL_EFFECT','Explain is not a pure function operation.',n.loc);continue;}
  fail('BIL_TYPE','Unknown statement.',n.loc);
 }return returned;}
 const global={symbols:globals,parent:null,global:true};statements(ast.body,global,null,true);
 for(const f of functions.values()){
  const e=child(global);for(const p of f.params){if(e.symbols.has(p.name))fail('BIL_NAME','Duplicate parameter.',p.loc);e.symbols.set(p.name,{type:p.type,mutable:true});}
  const key=memo?typeMemoKey(f,memo.source,{globals,records,functions,imports,hasDerive,ast,collections}):null,cached=memo?.previous?.types.get(f.name),before=typeBudget;
  if(cached?.key===key){
   typeBudget+=cached.cost;if(typeBudget>131072)fail('BIL_LIMIT','Compiler type expansion budget exceeded.',f.loc);
   f.body=relocate(cached.body,cached.loc,f.loc);if(cached.extended)ast.extended=true;memo.stats.reusedTypeFunctions++;
  }else{if(!statements(f.body,e,f.result,false,'function')&&f.result!=='Void')fail('BIL_RETURN','Function must return on every path.',f.loc);if(memo)memo.stats.recheckedFunctions++;}
  if(memo){memo.functionKeys.set(f.name,key);const entry=cached?.key===key?cached:{key,body:copy(f.body),loc:copy(f.loc),cost:typeBudget-before,extended:!!ast.extended};if(!entry.bytes)entry.bytes=JSON.stringify(entry).length*2;memo.next.types.set(f.name,entry);}
 }
 if(hasDerive){
  const declarations=new Map();ast.body.forEach((n,index)=>{if(n.global&&n.declaration)declarations.set(n.name,index);});
  const dependencies=(value,out,visited)=>{if(!value||typeof value!=='object')return;if(value.kind==='name'&&value.derivationGlobal)out.add(value.name);if(value.kind==='call'&&functions.has(value.call)&&!visited.has(value.call)){visited.add(value.call);dependencies(functions.get(value.call).body,out,visited);}for(const [key,child]of Object.entries(value))if(key!=='callee'&&child&&typeof child==='object')Array.isArray(child)?child.forEach(x=>dependencies(x,out,visited)):dependencies(child,out,visited);};
  ast.body.forEach((n,index)=>{if(n.kind!=='derive')return;const reads=new Set();dependencies(n.value,reads,new Set());for(const name of reads)if(name===n.name||!declarations.has(name)||declarations.get(name)>=index)fail('BIL_DERIVE','Derived values require earlier declared dependencies; cycles and forward reads are not allowed.',n.loc);n.dependencies=[...reads].sort();});
 }
 for(const h of handlers.values()){const e=child(global);for(const p of h.params||[]){if(globals.has(p.name)||backends.has(p.name)||functions.has(p.name)||handlers.has(p.name)||imports.has(p.name))fail('BIL_EVENT','Completion parameters cannot shadow application symbols.',p.loc);e.symbols.set(p.name,{type:p.type,mutable:false});}statements(h.body,e,null,false,'handler');}
 for(const h of handlers.values())if(h.params&&!h.completionUsed)fail('BIL_EVENT','A typed handler must be referenced by a checked remote request.',h.loc);
 for(const n of cancellations)if(!watches.has(n.subscription))fail('BIL_SUBSCRIPTION','Cancellation names an undeclared subscription.',n.loc);
 const starts=ast.body.filter(n=>n.kind==='start');if(starts.length>1||starts.length&&!screens.has(starts[0].name))fail('BIL_UI','start must identify one declared screen.',starts[0]?.loc);if(starts.length&&!screens.size)fail('BIL_UI','start requires screens.');
 let uiCount=0,worldCount=0;const uiIds=new Set();const field=(name,n)=>{const symbol=globals.get(name);if(!symbol)fail('BIL_UI','Component binds an undeclared application value '+name+'.',n.loc);return symbol;};
 function checkTriple(v,positive){if(!Array.isArray(v)||v.length!==3||v.some(x=>x&&typeof x==='object'?Object.keys(x).join()!=='bind'||globals.get(x.bind)?.type!=='Number':!Number.isFinite(x)||Math.abs(x)>10000||positive&&x<=0))fail('BIL_DEPTH','A3D vector needs three bounded numbers or Number bindings.');}
 function ui(nodes,depth=0,parent=null){if(depth>8)fail('BIL_LIMIT','UI nesting exceeds eight.');for(const n of nodes){if(++uiCount>(advancedUI?1024:128)||uiIds.has(n.id))fail('BIL_LIMIT','UI exceeds its unique component budget.',n.loc);uiIds.add(n.id);checkAppearance(n,globals,handlers);
  if(n.kind==='intent'){statements([n],global);continue;}
  if(['ui_input','ui_select','ui_toggle'].includes(n.kind)){const symbol=field(n.name,n),type=symbol.type;if(!symbol.mutable||!['Number','Text','Boolean'].includes(type))fail('BIL_UI','An input must bind a mutable primitive value.',n.loc);n.inputType=type;
   if(n.kind==='ui_toggle'&&type!=='Boolean'||n.kind==='ui_select'&&type!=='Text'||n.kind==='ui_input'&&!['Text','Number'].includes(type))fail('BIL_UI','Field component and value type disagree.',n.loc);
   if(n.multiline&&type!=='Text')fail('BIL_UI','Only Text inputs can be multiline.',n.loc);
   if(n.range&&!(type==='Number'&&n.range.length===2&&n.range.every(Number.isFinite)&&n.range[0]<n.range[1]))fail('BIL_UI','Numeric bounds must be a known increasing pair.',n.loc);
   if(n.kind==='ui_select'){if(!n.options||!n.options.length||n.options.length>32||n.options.some(v=>typeof v!=='string'||!v.trim()||v.length>200)||new Set(n.options).size!==n.options.length)fail('BIL_UI','Select needs 1–32 distinct text choices.',n.loc);}else if(n.options)fail('BIL_UI','Only select accepts options.',n.loc);
  }else if(n.kind==='ui_image'){const t=field(n.name,n).type;if(![...backends.values()].some(b=>b.adapter===NATIVE_ADAPTER||b.adapter==='firebase.development/4'))fail('BIL_UI','Native images require a declared Android native adapter.',n.loc);if(!same(t,nativeMediaType)&&!same(t,{nullable:nativeMediaType}))fail('BIL_UI','An image binds NativeMedia or NativeMedia?.',n.loc);}
   else if(n.kind==='ui_cards'){const type=field(n.name,n).type,selection=field(n.selection,n);if(!type?.list?.record||selection.type!=='Text'||!selection.mutable||type.list.record[n.identity]!=='Text')fail('BIL_UI','Cards need List<Record>, a Text identity field and a mutable Text selection.',n.loc);if(!n.columns.length||n.columns.length>8||new Set(n.columns.map(c=>c.field)).size!==n.columns.length||n.columns.some(c=>!['Text','Number','Boolean'].includes(type.list.record[c.field])||!c.label.trim()||c.label.length>200))fail('BIL_UI','Cards need 1–8 distinct primitive fields with bounded labels.',n.loc);for(const text of [n.label,n.actionLabel,n.empty])if(typeof text!=='string'||!text.trim()||text.length>200)fail('BIL_UI','Card labels require 1–200 text characters.',n.loc);if(!handlers.has(n.handler)||handlers.get(n.handler).params)fail('BIL_UI','A card action needs an existing ordinary event handler.',n.loc);if(n.image){const photo=type.list.record[n.image];if(![...backends.values()].some(b=>b.adapter===NATIVE_ADAPTER||b.adapter==='firebase.development/4')||!same(photo,nativeMediaType)&&!same(photo,{nullable:nativeMediaType}))fail('BIL_UI','Card images require a declared image adapter and NativeMedia or NativeMedia?.',n.loc);}
   }else if(n.kind==='ui_table'){const type=field(n.name,n).type,selection=field(n.selection,n);if(!type?.list?.record||selection.type!=='Number'||!selection.mutable)fail('BIL_UI','Table needs List<Record> and a mutable Number selection.',n.loc);if(!n.columns.length||n.columns.length>16||new Set(n.columns.map(c=>c.field)).size!==n.columns.length||n.columns.some(c=>!['Text','Number','Boolean'].includes(type.list.record[c.field])))fail('BIL_UI','Table columns must name 1–16 distinct primitive record fields.',n.loc);
  }else if(n.kind==='ui_button'){if(n.handler&&!handlers.has(n.handler)||n.target&&!screens.has(n.target))fail('BIL_UI','Button target is not declared.',n.loc);if(n.handler&&handlers.get(n.handler).params)fail('BIL_UI','Completion handlers cannot be invoked by a UI button.',n.loc);if(n.validate&&!n.handler)fail('BIL_UI','Validation belongs to a handler button.',n.loc);}
   else if(n.kind==='ui_clock'){if(!n.label.trim()||n.label.length>160||!Number.isInteger(n.interval)||n.interval<50||n.interval>1000||!handlers.has(n.handler)||handlers.get(n.handler).params)fail('BIL_SCENE','A clock needs a label, interval50–1000ms and an ordinary BIL handler.',n.loc);}
   else if(n.kind==='ui_pad'){if(!n.label.trim()||n.label.length>160||Object.values(n.directions).some(name=>!handlers.has(name)||handlers.get(name).params))fail('BIL_SCENE','A control pad needs five ordinary BIL handlers.',n.loc);}
   else if(n.kind==='ui_space'){if(n.camera&&n.camera.some(name=>globals.get(name)?.type!=='Number'))fail('BIL_SCENE','Camera needs three declared Number values: x, y, zoom.',n.loc);if(!n.label.trim()||n.label.length>160||n.spaceSize.some(v=>!Number.isFinite(v)||v<64||v>4096)||n.children.some(child=>!['ui_drawing','ui_sprite'].includes(child.kind)))fail('BIL_DRAW','A space needs dimensions64–4096 and only drawing objects as children.',n.loc);}
   else if(n.kind==='ui_drawing'){if(!n.label.trim()||n.label.length>160||!['object','actor','door','solid'].includes(n.role)||n.points.length<2||n.points.length>256||n.points.some(p=>p.some(v=>!Number.isFinite(v)||v<0||v>1000))||!Number.isFinite(n.weight)||n.weight<1||n.weight>16)fail('BIL_DRAW','A drawing requires2–256 bounded points, a supported role and stroke weight1–16.',n.loc);if(![n.fill,n.ink].every(c=>typeof c==='string'&&(/^(#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6})$/.test(c)||['transparent','currentColor'].includes(c))))fail('BIL_DRAW','Drawing colors require hexadecimal colors, transparent or currentColor.',n.loc);}
   else if(n.kind==='ui_world'){if(++worldCount>4)fail('BIL_DEPTH','Ekran podržava najviše četiri3D prostora.',n.loc);if(!n.label.trim()||n.label.length>160||!Number.isFinite(n.depthStrength)||n.depthStrength<0||n.depthStrength>1||!n.children.length||n.children.length>96||n.children.some(c=>c.kind!=='ui_mesh'))fail('BIL_DEPTH','World needs1–96 meshes and depth0–1.',n.loc);checkTriple(n.eye,false);checkTriple(n.aim,false);}
   else if(n.kind==='ui_mesh'){if(parent!=='ui_world')fail('BIL_DEPTH','Mesh pripada isključivo3D prostoru.',n.loc);if(!n.label.trim()||n.label.length>160||!['box','sphere','cylinder','torus','prism'].includes(n.meshGeometry)||!['matte','ceramic','metal','light'].includes(n.surface)||!/^#[0-9a-fA-F]{6}$/.test(n.tint))fail('BIL_DEPTH','Mesh needs a supported geometry, surface and hex color.',n.loc);checkTriple(n.origin,false);checkTriple(n.extent,true);checkTriple(n.rotation,false);if(n.meshGeometry==='prism'){if(!n.contour||n.contour.length<3||n.contour.length>128||n.contour.some(p=>p.length!==2||p.some(v=>!Number.isFinite(v)||v<0||v>1000)))fail('BIL_DEPTH','Prism needs3–128 contour points0–1000.',n.loc);if(typeof scope.CLEA7Depth?.triangulate!=='function')fail('BIL_DEPTH','Host treba zajednički depth.js validator kontura.',n.loc);scope.CLEA7Depth.triangulate(n.contour);}else if(n.contour)fail('BIL_DEPTH','Only a prism takes contour points.',n.loc);}
   else if(n.kind==='ui_sprite'){if(ast.resources?.items[n.asset]?.kind!=='image'||n.grid.length!==2||n.grid.some(x=>!Number.isInteger(x)||x<1||x>64)||n.grid[0]*n.grid[1]>256||n.frame&&globals.get(n.frame)?.type!=='Number')fail('BIL_RESOURCE','Sprite zahtijeva deklarisanu sliku,1–256 kadrova i numerički indeks.',n.loc);}
   else if(n.kind==='ui_sound'){if(ast.resources?.items[n.asset]?.kind!=='audio'||(!n.caption?.trim()||n.caption.length>200))fail('BIL_RESOURCE','Zvuk zahtijeva deklarisani audio resurs i vidljiv opis sadržaja.',n.loc);}
   else if(n.kind==='ui_shape'){if(!SHAPES.includes(n.geometry))fail('BIL_UI','Unsupported original geometric shape.',n.loc);}
  else if(!['ui_heading','ui_text','ui_card','ui_row'].includes(n.kind))fail('BIL_UI','Unsupported UI node.',n.loc);
  if(n.children)ui(n.children,depth+1,n.kind);
 }}for(const screen of screens.values()){worldCount=0;ui(screen.children);}
 if(ast.extended)for(const name of handlers.keys())if(name.startsWith('ui_'))fail('BIL_NAME','ui_ is reserved for checked UI entry points.');
 ast.format=ast.live?'bil/5':ast.async?'bil/4':ast.remote?'bil/3':ast.extended?'bil/2':VERSION;
 if(ast.remote)for(const [name,b]of backends){if(imports.has(name)||functions.has(name)||handlers.has(name)||globals.has(name))fail('BIL_NAME','Backend alias conflicts with an application symbol.');b.operations.sort();}

 if(globals.size>(advancedUI?128:64)||functions.size>(advancedUI?128:64)||handlers.size>(advancedUI?128:64)||[...functions.values()].some(f=>f.params.length>16))fail('BIL_LIMIT','BIL symbol or parameter budget exceeded.');return {advancedUI,collections,globals:Object.fromEntries(globals),records:Object.fromEntries(records),imports:[...imports].sort(),functions,handlers,screens,start:starts[0]?.name||[...screens.keys()][0]||'',...(ast.remote?{remote:{format:'bil.remote/1',backends:Object.fromEntries(backends)}}:{})};
}
function lower(ast,checked,memo=null){
 const sourceMap=[];
 const expr=n=>{if(n.kind==='choice')return {op:'SELECT',type:copy(n.type),condition:expr(n.condition),whenTrue:expr(n.then),whenFalse:expr(n.otherwise),loc:copy(n.loc)};const op={literal:'CONST',name:'LOAD',list:'LIST',recordValue:'RECORD',field:'FIELD',index:'INDEX',unary:'UNARY',binary:'BINARY',call:'CALL'}[n.kind],x={op,type:copy(n.type),loc:copy(n.loc)};for(const k of ['name','value','operator','call'])if(own(n,k)&&typeof n[k]!=='object')x[k]=n[k];if(n.kind==='literal')x.value=n.value;if(n.object)x.object=expr(n.object);if(n.index)x.index=expr(n.index);if(n.kind==='unary')x.value=expr(n.value);if(n.left)x.left=expr(n.left);if(n.right)x.right=expr(n.right);if(n.items)x.items=n.items.map(expr);if(n.fields)x.fields=Object.fromEntries(Object.entries(n.fields).map(([k,v])=>[k,expr(v)]));if(n.args)x.args=n.args.map(expr);return x;};
 const block=body=>body.filter(n=>!['record','function','handler','import','button','screen','start','backend'].includes(n.kind)).map(n=>{if(n.kind==='guard'){const failure={op:'RAISE',id:n.id+'_failure',loc:copy(n.failureLoc),code:n.code,value:expr(n.value)},x={op:'BRANCH',id:n.id,loc:copy(n.loc),condition:expr(n.condition),then:[],otherwise:[failure]};sourceMap.push({id:n.id,op:'BRANCH',coreFeature:'guard',...copy(n.loc)},{id:failure.id,op:'RAISE',...copy(n.failureLoc)});return x;}if(n.kind==='request'||n.kind==='watch'){const x={op:n.kind==='watch'?'WATCH':'REQUEST',id:n.id,loc:copy(n.loc),backend:n.backend,operation:n.operation,args:n.args.map(expr),target:n.name,error:n.error,resultType:copy(n.resultType),...(n.completion?{completion:copy(n.completion)}:{}),...(n.kind==='watch'?{subscription:n.subscription,interval:n.interval}:{})};sourceMap.push({id:n.id,op:x.op,...copy(n.loc)});return x;}if(n.kind==='unwatch'){const x={op:'UNWATCH',id:n.id,loc:copy(n.loc),subscription:n.subscription};sourceMap.push({id:n.id,op:x.op,...copy(n.loc)});return x;}const op={declare:'STORE_NEW',derive:'STORE_NEW',assign:n.declaration?'STORE_NEW':'STORE',if:'BRANCH',while:'LOOP_WHILE',repeat:'LOOP_COUNT',for:'LOOP_LIST',return:'RETURN',raise:'RAISE',try:'TRY',expression:'EVAL',intent:'INTENT',move:'MOTION',explain:'EXPLAIN',open:'NAVIGATE'}[n.kind],x={op,id:n.id,loc:copy(n.loc)};sourceMap.push({id:n.id,op,...(['derive','while'].includes(n.kind)?{coreFeature:n.kind}:{}),...copy(n.loc)});if(n.kind==='while'){x.coreFeature='while';x.limit=n.limit;}if(n.kind==='derive'){x.coreFeature='derive';x.dependencies=n.dependencies.slice();}for(const k of ['name','mutable','global','declaredType','mode','ai','within','fallback','inputType','code'])if(own(n,k))x[k]=copy(n[k]);if(n.value)x.value=expr(n.value);if(n.target&&!n.declaration)x.target=expr(n.target);if(n.condition)x.condition=expr(n.condition);if(n.count)x.count=expr(n.count);if(n.range)x.range=n.range.map(expr);if(n.body)x.body=block(n.body);if(n.then)x.then=block(n.then);if(n.otherwise)x.otherwise=block(n.otherwise);if(n.recover)x.recover=block(n.recover);return x;});
 const functions={};for(const [name,f]of checked.functions){
  const key=memo?.functionKeys.get(name),cached=memo?.previous?.lower.get(name),before=sourceMap.length;
  if(cached?.key===key&&memo){functions[name]=relocate(cached.ir,cached.loc,f.loc);sourceMap.push(...relocate(cached.map,cached.loc,f.loc));memo.stats.reusedLoweredFunctions++;}
  else{functions[name]={params:f.params.map(p=>({name:p.name,type:p.type})),result:f.result,body:block(f.body)};if(memo)memo.stats.loweredFunctions++;}
  if(memo){const entry=cached?.key===key?cached:{key,ir:copy(functions[name]),map:copy(sourceMap.slice(before)),loc:copy(f.loc)};if(!entry.bytes)entry.bytes=JSON.stringify(entry).length*2;memo.next.lower.set(name,entry);}
 }
 const handlers={};for(const [name,h]of checked.handlers)handlers[name]=block(h.body);
 const main=block(ast.body);let ui=null;
 if(ast.extended){const compileUI=(nodes,screen)=>nodes.map(n=>{let x;
  if(n.kind==='intent'){const instruction=block([n])[0];main.push(instruction);x={id:n.id,type:'view',loc:copy(n.loc),target:n.value.name};}
  else{x={id:n.id,type:n.kind.slice(3),loc:copy(n.loc)};for(const k of ['eye','aim','depthStrength','meshGeometry','origin','extent','rotation','surface','tint','contour','label','name','required','multiline','range','options','inputType','columns','selection','handler','target','validate','identity','image','actionLabel','empty','points','role','closed','fill','ink','weight','spaceSize','camera','interval','directions','asset','grid','frame','caption'])if(own(n,k))x[k]=copy(n[k]);}
  if(n.children)x.children=compileUI(n.children,screen);
  if(['input','select','toggle','table','cards','button','clock','pad'].includes(x.type)){const name='ui_'+n.id;handlers[name]=[{op:'UI_EVENT',id:n.id,loc:copy(n.loc),screen,control:n.id}];sourceMap.push({id:n.id,op:'UI_EVENT',...copy(n.loc)});x.entry=name;}
  for(const key of ['style','motion','geometry'])if(own(n,key))x[key]=copy(n[key]);
  if(n.gestures){x.gestures={};let i=0;for(const [gesture,handler]of Object.entries(n.gestures)){const id=n.id+'_g'+i++,entry='ui_'+id,loc=copy(n.gestureLocs[gesture]);x.gestures[gesture]={handler,entry};handlers[entry]=[{op:'UI_EVENT',id,loc,screen,control:n.id,gesture}];sourceMap.push({id,op:'UI_EVENT',...loc});}}
  return x;});ui={format:checked.collections?'bil.ui/3':checked.advancedUI?'bil.ui/2':'bil.ui/1',start:checked.start,screens:[...checked.screens.values()].map(n=>({id:n.name,label:n.label,loc:copy(n.loc),children:compileUI(n.children,n.name)}))};}
 if(new Set(sourceMap.map(x=>x.id)).size!==sourceMap.length)fail('BIL_ID','Source identifiers collided; rename a value or handler.');const controls=ast.body.filter(n=>n.kind==='button').map(n=>({id:n.id,label:n.label,handler:n.name}));
 return {format:ast.live?'bil.ir/5':ast.async?'bil.ir/4':ast.remote?'bil.ir/3':ast.extended?'bil.ir/2':IR,language:ast.format,globals:copy(checked.globals),records:copy(checked.records),imports:checked.imports,functions,handlers,main,controls,sourceMap,...(ast.objects?{objects:copy(ast.objects)}:{}),...(ast.resources?{resources:copy(ast.resources)}:{}),...(ast.extended?{ui}:{}),...(ast.remote?{remote:copy(checked.remote)}:{}),...((ast.async||ast.live)?{events:{format:'bil.events/1',handlers:Object.fromEntries([...checked.handlers].filter(([,h])=>h.params).map(([name,h])=>[name,h.params.map(p=>({name:p.name,type:copy(p.type)}))]))}}:{})};
}
function defaultValue(type){if(type==='Number')return 0;if(type==='Text')return '';if(type==='Boolean')return false;if(type?.nullable)return null;if(type?.list)return [];if(type?.record)return Object.fromEntries(Object.entries(type.record).map(([k,t])=>[k,defaultValue(t)]));fail('BIL_TYPE','Unsupported stored type.');}
function application(ir,source,metadata={}){const live=ir.format==='bil.ir/5',async=live||ir.format==='bil.ir/4',remote=async||ir.format==='bil.ir/3',extended=remote||ir.format==='bil.ir/2';const app={format:live?'clea7.application/9':async?'clea7.application/8':remote?'clea7.application/7':extended?'clea7.application/6':'clea7.application/5',id:metadata.id||'bil_program',name:metadata.name||ir.objects?.title||'Moja BIL aplikacija',package:metadata.package||'com.brzoilokalno.bil.app',version:metadata.version||1,start:'home',permissions:[],state:{bilValues:Object.fromEntries(Object.entries(ir.globals).map(([k,v])=>[k,defaultValue(v.type)])),bilViews:[],bilMotion:[],...(extended?{bilScreen:ir.ui.start}:{})},screens:[{id:'home',name:'BIL',children:[{id:'bil_surface',type:'bil'},...ir.controls.map(c=>({id:c.id,type:'button',text:c.label,events:{click:'bil_'+c.handler}}))]}],flows:{bil_main:[{action:'bil',block:'main'}]},tables:{},machines:{},animations:{},components:{},bil:{format:live?'bil.program/5':async?'bil.program/4':remote?'bil.program/3':extended?'bil.program/2':'bil.program/1',source,ir}};if(remote){app.remote=copy(ir.remote);app.permissions=[...new Set(Object.values(ir.remote.backends).filter(b=>[NATIVE_ADAPTER,SENSE_ADAPTER].includes(b.adapter)).flatMap(b=>b.operations.map(op=>(b.adapter===SENSE_ADAPTER?SENSE_CONTRACTS:NATIVE_CONTRACTS)[op].permission).filter(Boolean)))].sort();}if(ir.resources)app.resources=copy(metadata.resources||{format:'clea7.resources/1',items:[]});if(metadata.licenses!==undefined)app.licenses=copy(metadata.licenses);for(const name of Object.keys(ir.handlers))app.flows['bil_'+name]=[{action:'bil',block:name}];return app;}
function legacy(ast,metadata={}){if(ast.objects||ast.resources||metadata.licenses?.length)return null;const state={},children=[];for(const n of ast.body){if((n.kind==='declare'||n.kind==='assign'&&n.declaration)&&n.value.kind==='literal'&&n.value.value!==null){state[n.name]=n.value.value;}else if(n.kind==='intent'&&n.mode==='show'&&!n.ai&&!n.within&&!n.range&&!n.fallback&&own(state,n.value.name)){children.push({id:n.id,type:'text',text:{ref:'state',key:n.value.name}});}else return null;}return {format:'clea7.application/2',id:metadata.id||'bil_program',name:metadata.name||'Moja BIL aplikacija',package:metadata.package||'com.brzoilokalno.bil.app',version:metadata.version||1,start:'home',permissions:[],state,screens:[{id:'home',name:'BIL',children}],flows:{},tables:{}};}
function featureMetadata(ast){const used=new Set(ast.objects?['object.sentences',...(ast.objects.views?['object.views']:[])]:[]),walk=value=>{if(!value||typeof value!=='object')return;if(value.kind==='ui_world')used.add('depth.world');if(['ui_clock','ui_pad'].includes(value.kind)||value.kind==='ui_space'&&value.camera)used.add('scene.ui');if(value.kind==='call'&&value.call?.startsWith('scene.'))used.add(value.call);if(['guard','derive','while'].includes(value.kind))used.add(value.kind);if(value.kind==='call'&&CORE_FEATURES.operations.includes(value.call))used.add(value.call);for(const child of Object.values(value))if(child&&typeof child==='object')Array.isArray(child)?child.forEach(walk):walk(child);};walk(ast);if(ast.resources)for(const row of Object.values(ast.resources.items))used.add('resource.'+row.kind);const core4=[...used].some(x=>x.startsWith('scene.'));const core3=[...used].some(x=>['derive','while','json.encode','json.decode'].includes(x));return {format:CORE_FEATURES.format,version:used.has('depth.world')?8:ast.resources?7:ast.objects?.views?6:ast.objects?5:core4?4:core3?3:used.size?2:1,minimumRuntime:used.has('depth.world')?'0.47.0':ast.resources?'0.46.0':ast.objects?.views?'0.45.0':ast.objects?'0.44.0':core4?'0.42.0':core3?'0.18.0':used.size?'0.17.0':'0.6.0',used:[...used].sort()};}
function compileBuild(source,metadata={},memo=null){
 const clock=()=>scope.performance?.now?.()||Date.now(),start=clock(),ast=new Parser(source).program(memo),parsed=clock(),checked=check(ast,memo),typed=clock(),ir=lower(ast,checked,memo),lowered=clock(),features=featureMetadata(ast);
 if(memo)Object.assign(memo.stats,{parseMs:parsed-start,typeMs:typed-parsed,lowerMs:lowered-typed});
 return {format:'bil.compilation/1',ast,ir,sourceMap:ir.sourceMap,application:application(ir,source,metadata),application2:legacy(ast,metadata),...(features.version>=2?{features}:{})};
}
function compile(source,metadata={}){return compileBuild(source,metadata);}
function createSession({scope:identity='project'}={}){
 if(typeof identity!=='string'||!identity.length||identity.length>128||/[\u0000-\u001f]/.test(identity))fail('BIL_CACHE','Compiler session needs a bounded explicit project scope.');
 let previous=null,last=null,stats=null,closed=false;
 const clock=()=>scope.performance?.now?.()||Date.now(),maximum=8*1024*1024;
 return Object.freeze({
  compile(source,metadata={}){
   if(closed)fail('BIL_CACHE','This compiler session is closed.');const began=clock();
   stats={format:'bil.incremental/1',scope:identity,parsedUnits:0,reusedUnits:0,recheckedFunctions:0,reusedTypeFunctions:0,loweredFunctions:0,reusedLoweredFunctions:0,lexedTokens:0,fullResultHit:false,passed:false,retainedBytes:0};
   if(Object.keys(metadata).some(k=>!['id','name','package','version','licenses','resources'].includes(k))){const result=compile(source,metadata);Object.assign(stats,{passed:true,cacheDisabled:'unknown-metadata',totalMs:clock()-began});return result;}
   const meta=JSON.stringify(metadata);
   if(last?.source===source&&last.meta===meta){const saved=JSON.parse(last.result),ir=saved.ir,result={format:'bil.compilation/1',ast:saved.ast,ir,sourceMap:ir.sourceMap,application:application(ir,source,JSON.parse(last.meta)),application2:saved.application2,...(saved.features?{features:saved.features}:{})};Object.assign(stats,{passed:true,fullResultHit:true,totalMs:clock()-began,retainedBytes:last.bytes});return result;}
   const memo={source,previous,next:{units:[],types:new Map(),lower:new Map()},functionKeys:new Map(),stats};
   try{
    const result=compileBuild(source,metadata,memo),encoded=JSON.stringify({ast:result.ast,ir:result.ir,application2:result.application2,...(result.features?{features:result.features}:{})});
    const retained=[...memo.next.units,...memo.next.types.values(),...memo.next.lower.values()].reduce((sum,x)=>sum+x.bytes,0)+(encoded.length+source.length+meta.length)*2+4096;
    if(retained<=maximum){previous=memo.next;last={source,meta,result:encoded,bytes:retained};stats.retainedBytes=retained;}
    else{previous=null;last=null;stats.cacheDisabled='capacity';}
    Object.assign(stats,{passed:true,totalMs:clock()-began});return result;
   }catch(error){Object.assign(stats,{passed:false,errorCode:error.code||'CompilerError',totalMs:clock()-began,retainedBytes:last?.bytes||0});throw error;}
  },
  statistics(){return stats?copy(stats):{format:'bil.incremental/1',scope:identity,retainedBytes:0};},
  clear(){previous=null;last=null;stats=null;},
  close(){previous=null;last=null;stats=null;closed=true;}
 });
}
function featuresFor(value){const source=typeof value==='string'?value:value?.application?.bil?.source;if(typeof source!=='string')fail('BIL_FEATURES','Expected BIL source or a compilation result.');const result=compile(source);return result.features||{format:CORE_FEATURES.format,version:1,minimumRuntime:'0.6.0',used:[]};}
function validateApplication(p){const ir=validateBundle(p.bil),expected=application(ir,p.bil.source,p),stable=scope.CLEA7?.stable||JSON.stringify;for(const key of ['format','state','screens','flows','tables','machines','animations','components','permissions','start',...((p.remote!==undefined||expected.remote!==undefined)?['remote']:[])])if(stable(p[key])!==stable(expected[key]))fail('BIL_INTEGRITY','BIL-generated '+key+' must be changed through BIL source.');return ir;}
function validateBundle(bundle){if(!bundle||Object.keys(bundle).sort().join('|')!=='format|ir|source'||!['bil.program/1','bil.program/2','bil.program/3','bil.program/4','bil.program/5'].includes(bundle.format)||typeof bundle.source!=='string')fail('BIL_BUNDLE','Invalid BIL source/IR envelope.');const result=compile(bundle.source);const stable=scope.CLEA7?.stable||JSON.stringify;if(bundle.format!==(result.ir.format==='bil.ir/5'?'bil.program/5':result.ir.format==='bil.ir/4'?'bil.program/4':result.ir.format==='bil.ir/3'?'bil.program/3':result.ir.format==='bil.ir/2'?'bil.program/2':'bil.program/1')||stable(bundle.ir)!==stable(result.ir))fail('BIL_INTEGRITY','BIL IR does not match the statically checked source.');return result.ir;}
function visual(source){const result=compile(source);return {source,ir:result.ir,nodes:result.ast.body.map(n=>({id:n.id,kind:n.kind,name:n.name||n.value?.name||'',location:n.loc,editable:(n.kind==='declare'||n.kind==='assign'&&n.declaration)&&n.value.kind==='literal',value:n.value?.kind==='literal'?n.value.value:undefined,valueLocation:n.value?.loc||null})),diagnostics:[]};}
function editLiteral(source,id,value){const model=visual(source),node=model.nodes.find(n=>n.id===id);if(!node?.editable)fail('BIL_VISUAL','This construct is preserved; edit it in BIL code.');if(value!==null&&!['number','string','boolean'].includes(typeof value)||typeof value==='number'&&!Number.isFinite(value))fail('BIL_VISUAL','Expected a finite literal.');const out=source.slice(0,node.valueLocation.start)+(model.ir.objects&&typeof value==='boolean'?(value?'da':'ne'):JSON.stringify(value))+source.slice(node.valueLocation.end);compile(out);return out;}
// Public authoring operations preserve the sentence source and use its parser.
function objectWrite(source,operation){
 const compiled=compile(source);if(!compiled.ir.objects)fail('BIL_OBJECT','Odaberi projekt s BIL zaglavljem za gramatiku objekata.');
 if(!operation||typeof operation!=='object'||Array.isArray(operation))fail('BIL_OBJECT','Potrebna je definicija radnje objekta.');
 const allowed={remember:['object','field','type','value'],derive:['object','field','expression','whenTrue','whenFalse'],action:['object','field','action','expression','label'],label:['object','field','label']},kind=operation.kind;
 if(!own(allowed,kind)||Object.keys(operation).some(k=>k!=='kind'&&!allowed[kind].includes(k)))fail('BIL_OBJECT','Nepoznata radnja ili parametar objekta.');
 for(const key of ['object','field',...(kind==='action'?['action']:[])])if(!safe(operation[key])||reserved.has(operation[key])||operation[key].length>48)fail('BIL_OBJECT','Neispravno ime objekta, polja ili radnje.');
 const text=value=>{if(typeof value!=='string'||!value.trim()||value.length>200)fail('BIL_OBJECT','Naziv treba 1–200 znakova.');return JSON.stringify(value);};
 const literal=value=>{if(typeof value==='boolean')return value?'da':'ne';if(typeof value==='string')return JSON.stringify(value);if(typeof value!=='number'||!Number.isFinite(value)||Math.abs(value)>1e15)fail('BIL_OBJECT','Vrijednost treba tekst, logiku ili konačan broj.');
  const number=String(value);if(!/[eE]/.test(number))return number;const parts=Math.abs(value).toString().split('e'),digits=parts[0].replace('.',''),point=(parts[0].split('.')[0].length)+Number(parts[1]),sign=value<0?'-':'';return sign+(point<=0?'0.'+'0'.repeat(-point)+digits:point>=digits.length?digits+'0'.repeat(point-digits.length):digits.slice(0,point)+'.'+digits.slice(point));};
 const expression=value=>{if(typeof value!=='string'||!value.trim()||value.length>800||/[\r\n;]/.test(value))fail('BIL_OBJECT','Izraz treba jednu ograničenu BIL rečenicu.');return value;};
 let sentence;
 if(kind==='remember'){const type={Number:'broj',Text:'tekst',Boolean:'logiku'}[operation.type];if(!type)fail('BIL_OBJECT','Podržani tip je Number, Text ili Boolean.');sentence=operation.object+' pamti '+operation.field+' kao '+type+' '+literal(operation.value)+'.';}
 else if(kind==='derive'){
  sentence=operation.object+' izvodi '+operation.field+' iz '+expression(operation.expression);
  if(own(operation,'whenTrue')||own(operation,'whenFalse')){if(!own(operation,'whenTrue')||!own(operation,'whenFalse'))fail('BIL_OBJECT','Izbor treba obje grane.');sentence+=':\n    ne daje '+literal(operation.whenFalse)+';\n    da daje '+literal(operation.whenTrue);}
  sentence+='.';
 }else if(kind==='action'){
  sentence=operation.action+' nad '+operation.object+' postavlja '+operation.field+' na '+expression(operation.expression)+'.';
  if(own(operation,'label'))sentence+='\n'+operation.object+' nudi '+text(operation.label)+' kao '+operation.action+'.';
 }else sentence=operation.object+' prikazuje '+operation.field+' kao '+text(operation.label)+'.';
 const next=source+'\n'+sentence+'\n';compile(next);return next;
}
scope.CLEA7BIL={objectWrite,CORE_FEATURES,featuresFor,PRESENTATION,SHAPES,GESTURES,MOTIONS,VERSION,IR,PRIVATE_ADAPTER,PRIVATE_CONTRACTS,NATIVE_ADAPTER,NATIVE_CONTRACTS,SENSE_ADAPTER,SENSE_CONTRACTS,IMAGE_CONTRACTS,remoteImageType,nativeMediaType:copy(nativeMediaType),nativeLocationType:copy(nativeLocationType),nativeNotificationType:copy(nativeNotificationType),nativeReceiptType:copy(nativeReceiptType),REMOTE_CONTRACTS,remoteSessionType:copy(remoteSessionType),remoteFailureType:copy(remoteFailureType),remoteCompletionType:copy(remoteCompletionType),remoteUpdateType:copy(remoteUpdateType),remoteQueryType:copy(remoteQueryType),remoteDocumentType:copy(remoteDocumentType),Diagnostic,lex,parse:source=>new Parser(source).program(),check,compile,createSession,validateBundle,validateApplication,defaultValue,visual,editLiteral,safe,copy};
})(globalThis);

