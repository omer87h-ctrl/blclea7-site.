# Original CLEA conversation model 0.1

This folder contains genuinely trained original parameters and a genuinely
autoregressive decoder. It does not contain a downloaded/pretrained model or a
reference-answer lookup table. The neural decoder does not read the corpus at
inference time. The Runtime must separately control scope, evidence, permissions,
resource limits, cancellation, recovery and presentation.

The architecture is a small conditional tanh RNN: learned question embeddings
condition every token decoder step; an independent learned token embedding and
recurrent state predict the next token with a softmax. Training uses explicit
NumPy BPTT, Adam and gradient norm clipping. These are standard mathematical
principles implemented for CLEA, not a claim that the principles are novel.

- 135,349 parameters, 725-token train-only vocabulary, embedding32/hidden96.
- Original corpus: 300 training and60 heldout prompts across20 CLEA topics in
  Bosnian and English. It contains no private user data or third-party weights.
- Actual CPU training:1600 steps, seed7020, batch24. It took about14.7seconds in
  the initial measured environment, which is not a performance guarantee.
- Exact training answer tokens:300/300. Fixed heldout exact tokens:51/60(85%).
  The heldout questions paraphrase facts present during training. This does not
  measure new-fact learning, broad reasoning or real-world factual accuracy.
- On nine heldout questions the raw decoder chose an incorrect topic, sometimes
  confidently. A model score is not a truth score. The Runtime must reject a
  neural answer that does not match its source-linked permitted topic, or label
  a factual fallback clearly. Do not present a fallback as neural generation.
- Model JSON732,175bytes; decoded parameter bytes541,396. Neither value measures
  the total JavaScript heap or OS process RAM.
- Model fingerprint:
  `4a2ecae4216ae50ccbf0d2280331ea1f59bfe2a691aa22bcddd2bfa211e15e76`.

No mandatory server/API, external inference service, hidden model download or
automatic user-input training is used. Bundling this small original model with
a web application still transfers ordinary application bytes when that page
loads; it does not create knowledge without data/training or physical storage.
It is not a general chat model comparable to frontier systems.

## Reproduce and verify

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python scripts/train_clea_chat.py \
  --output neural/another-model.json --report neural/another-report.json
python scripts/check_clea_chat_training.py
node neural/test_decoder.cjs
node scripts/evaluate_clea_chat.cjs
```

Training refuses overwrite unless explicitly requested. The tokenizer, split,
seed, configuration and provenance are included in the model. `--check-gradients`
checks independent finite differences without training a replacement.

## Runtime API

`CLEA7NeuralChat.create(modelJSON)` returns `verify()`, `describe()`, `inspect()`
and asynchronous `generate(question, options)`. Options support explicit
`language: 'bs' | 'en'`, `maxTokens`1–48, `AbortSignal` and token callbacks.
The decoder verifies all parameter hashes and the whole model fingerprint before
generation. It accepts bounded data, performs numerical inference, and has no
host executor, network, shell, DOM, permission grant or arbitrary script loader.

`inspect()` exposes bounded numeric forward snapshots for independent parity
tests, not the reasoning of an intelligent agent. The raw output must still be
evaluated by the application's factual/scope policy. Browser-worker isolation
does not itself sandbox arbitrary hostile native code; no such code is accepted.

Original project notices and the corpus's declared licence/provenance remain in
force. This module does not change the platform licence or assert worldwide
novelty, patent clearance, absolute safety or frontier-model equivalence.
