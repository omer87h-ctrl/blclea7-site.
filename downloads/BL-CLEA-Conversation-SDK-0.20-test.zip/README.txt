BL CLEA original conversation model + local SDK — 0.20-test
by Brzo i Lokalno. Core0.18; own model0.1. No native installer is included.

Node.js20+ is needed for this developer CLI, not for the hosted browser app:
  node sdk/clea-chat.cjs validate
  node sdk/clea-chat.cjs info
  node sdk/clea-chat.cjs ask "Sta je BIL?" --language bs --no-cache

The SDK executes the same reviewed BIL Core, Runtime and original neural decoder
as the browser. All model/knowledge files are included. No inference API,
external model, GPU, account, telemetry or server is required. Node inference is
in process; this is not an OS sandbox for arbitrary hostile code. Only the
reviewed fixed platform sources are loaded. Questions are bounded data.

The learned conditional RNN has135349parameters. Its initial domain is20CLEA
topics in Bosnian/English, not general knowledge. On the fixed paraphrase set,
raw generation matches51/60known answers. Factual fallback and abstention are
separate Runtime modes, never represented as successful neural answers.

Reproduce training with Python3.12 and NumPy2.3.5 (development dependency):
  python scripts/train_clea_chat.py --output neural/retrained.json --report neural/retrained-report.json
Training never reads user conversations or downloads weights. See neural/README.md
and docs/CLEA-CONVERSATION-020.md for full architecture, provenance and limits.

Use the browser Studio on the official site to interact without installing
developer tools. This SDK ZIP is not that GUI or a native Android/Windows build.
Existing project notices remain unchanged; this package grants no new licence.
It is an unsigned test distribution. Inventory hashes prove bytes, not identity
or safety. The recorded browser/deployment results must be checked separately.
