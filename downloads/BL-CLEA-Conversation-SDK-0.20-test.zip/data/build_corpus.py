"""Original bounded CLEA knowledge conversation corpus. No web or user data.

The facts were checked against owner-controlled repository documentation and
code. This is synthetic expert-domain training material, not general knowledge
or an independently calibrated benchmark. Heldout prompts are fixed separately.
"""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent


def topic(identifier, source, bs_answer, en_answer, bs_questions, en_questions,
          bs_heldout, en_heldout):
    assert len(bs_questions) == 8 and len(en_questions) == 7, identifier
    assert len(bs_heldout) == 2 and len(en_heldout) == 1, identifier
    return {
        'id': identifier, 'source': source,
        'fact': {'bs': bs_answer, 'en': en_answer},
        'train': [{'question': text, 'answer': bs_answer, 'topic': identifier, 'language': 'bs'}
                  for text in bs_questions] +
                 [{'question': text, 'answer': en_answer, 'topic': identifier, 'language': 'en'}
                  for text in en_questions],
        'heldout': [{'question': text, 'answer': bs_answer, 'topic': identifier, 'language': 'bs'}
                    for text in bs_heldout] +
                   [{'question': text, 'answer': en_answer, 'topic': identifier, 'language': 'en'}
                    for text in en_heldout],
    }


TOPICS = [
topic('greeting', 'docs/CLEA-AI-EXPERIMENT.md',
    'Zdravo. Ja sam CLEA razgovorni eksperiment. Mogu pomoći oko provjerenih CLEA tema i objasniti svoja ograničenja.',
    'Hello. I am the CLEA conversation experiment. I can help with verified CLEA topics and explain my limits.',
    ['Zdravo, ko si ti?', 'Pozdrav, predstavi se.', 'Ćao, šta si ti?', 'Dobar dan, ko razgovara sa mnom?',
     'Kako se zoveš?', 'Reci mi nešto o sebi.', 'Možeš li se predstaviti?', 'Hvala, ko mi ovdje pomaže?'],
    ['Hello, who are you?', 'Hi, introduce yourself.', 'What is your name?', 'Tell me about yourself.',
     'Good morning, who am I talking to?', 'Can you introduce yourself?', 'Thanks, who is helping me here?'],
    ['Pozdrav, kako da te zovem?', 'Zdravo, predstavi svoj zadatak.'],
    ['Hello, tell me your name and purpose.']),

topic('scope', 'docs/CLEA-AI-EXPERIMENT.md',
    'Moje znanje je ograničeno na provjerene CLEA teme. Nisam opći ekspert i nemam potvrđene odgovore za svako pitanje.',
    'My knowledge is limited to verified CLEA topics. I am not a general expert and cannot answer every question reliably.',
    ['Da li znaš sve?', 'Možeš li odgovoriti na svako pitanje?', 'Koliko je široko tvoje znanje?', 'Jesi li opći ekspert?',
     'Možeš li zamijeniti svaki veliki model?', 'Znaš li sve o svijetu?', 'Da li je svaki tvoj odgovor tačan?', 'Šta ne znaš?'],
    ['Do you know everything?', 'Can you answer every question?', 'How broad is your knowledge?', 'Are you a general expert?',
     'Can you replace every large model?', 'Do you know everything about the world?', 'Is every answer correct?'],
    ['Koje su granice tvog znanja?', 'Da li pouzdano znaš odgovor na sve?'],
    ['What are the limits of your knowledge?']),

topic('core_ai_manager', 'docs/CLEA-CORE.md;docs/CLEA-AI-EXPERIMENT.md',
    'Core AI Manager koordinira zadatke, rokove i granice resursa. Opcionalni model ne dobija pravo da zaobiđe provjere.',
    'Core AI Manager coordinates tasks, deadlines and resource limits. An optional model does not gain permission to bypass checks.',
    ['Šta radi Core AI Manager?', 'Objasni stub Core AI Manager.', 'Ko upravlja zadacima i rokovima?',
     'Kako Core AI Manager kontroliše resurse?', 'Koji je posao Core AI Managera?', 'Zašto postoji Core AI Manager?',
     'Ko koordinira AI zadatke?', 'Da li Core AI Manager zaobilazi provjere?'],
    ['What does Core AI Manager do?', 'Explain the Core AI Manager pillar.', 'Who coordinates tasks and deadlines?',
     'How does Core AI Manager control resources?', 'What is the role of Core AI Manager?',
     'Why is Core AI Manager needed?', 'Can Core AI Manager bypass checks?'],
    ['Kako se u Core AI Manageru ograničavaju zadaci?', 'Za šta je odgovoran stub Core AI Manager?'],
    ['Which responsibility belongs to Core AI Manager?']),

topic('link_bridge_elite', 'docs/CLEA-CORE.md;docs/CLEA-AI-EXPERIMENT.md',
    'Link Bridge Elite povezuje kompajler, Core i host preko provjerenih ugovora. Svaka tražena mogućnost mora biti dostupna i dozvoljena.',
    'Link Bridge Elite connects the compiler, Core and host through checked contracts. Every requested capability must be available and permitted.',
    ['Šta radi Link Bridge Elite?', 'Objasni stub Link Bridge Elite.', 'Ko povezuje kompajler i host?',
     'Kako Link Bridge Elite povezuje komponente?', 'Koji je posao Link Bridge Elite?', 'Zašto postoji Link Bridge Elite?',
     'Ko provjerava ugovore između komponenti?', 'Da li Link Bridge Elite daje sve dozvole?'],
    ['What does Link Bridge Elite do?', 'Explain the Link Bridge Elite pillar.', 'Who connects the compiler and host?',
     'How does Link Bridge Elite connect components?', 'What is the role of Link Bridge Elite?',
     'Why is Link Bridge Elite needed?', 'Does Link Bridge Elite grant every permission?'],
    ['Kako Link Bridge Elite provjerava povezivanje?', 'Za šta je odgovoran stub Link Bridge Elite?'],
    ['Which responsibility belongs to Link Bridge Elite?']),

topic('expansion_q', 'docs/CLEA-CORE.md;docs/CLEA-AI-EXPERIMENT.md',
    'Expansion Q održava verzionisane registre podržanih operacija i prikaza. Proširenje mora poštovati provjereni ugovor i sigurnosne granice.',
    'Expansion Q maintains versioned registries of supported operations and views. Extensions must respect checked contracts and security boundaries.',
    ['Šta radi Expansion Q?', 'Objasni stub Expansion Q.', 'Ko održava registar operacija?',
     'Kako Expansion Q upravlja proširenjima?', 'Koji je posao Expansion Q?', 'Zašto postoji Expansion Q?',
     'Ko održava verzije podržanih prikaza?', 'Da li Expansion Q dozvoljava proizvoljan kod?'],
    ['What does Expansion Q do?', 'Explain the Expansion Q pillar.', 'Who maintains operation registries?',
     'How does Expansion Q manage extensions?', 'What is the role of Expansion Q?',
     'Why is Expansion Q needed?', 'Does Expansion Q allow arbitrary code?'],
    ['Kako se u Expansion Q provjeravaju proširenja?', 'Za šta je odgovoran stub Expansion Q?'],
    ['Which responsibility belongs to Expansion Q?']),

topic('adaptive_recovery', 'docs/CLEA-CORE.md;docs/APPLICATION-2.md',
    'Adaptive Recovery štiti lokalne transakcije i vraća stanje poslije greške. Neizvjesne vanjske radnje ne ponavlja automatski.',
    'Adaptive Recovery protects local transactions and restores state after failure. It does not automatically repeat uncertain external actions.',
    ['Šta radi Adaptive Recovery?', 'Objasni stub Adaptive Recovery.', 'Ko vraća stanje poslije greške?',
     'Kako Adaptive Recovery štiti transakcije?', 'Koji je posao Adaptive Recovery?', 'Zašto postoji Adaptive Recovery?',
     'Ko obrađuje neizvjesne vanjske radnje?', 'Da li Adaptive Recovery automatski ponavlja vanjske radnje?'],
    ['What does Adaptive Recovery do?', 'Explain the Adaptive Recovery pillar.', 'Who restores state after failure?',
     'How does Adaptive Recovery protect transactions?', 'What is the role of Adaptive Recovery?',
     'Why is Adaptive Recovery needed?', 'Does Adaptive Recovery repeat uncertain external actions?'],
    ['Kako Adaptive Recovery čuva prethodno stanje?', 'Za šta je odgovoran stub Adaptive Recovery?'],
    ['Which responsibility belongs to Adaptive Recovery?']),

topic('holo_interaction', 'docs/CLEA-CORE.md;docs/CLEA-AI-EXPERIMENT.md',
    'Holo Interaction prikazuje interfejs i povezuje korisničke događaje sa stanjem. Animacije poštuju podržane postavke smanjenog kretanja.',
    'Holo Interaction renders the interface and connects user events to state. Animations respect supported reduced motion preferences.',
    ['Šta radi Holo Interaction?', 'Objasni stub Holo Interaction.', 'Ko prikazuje interfejs aplikacije?',
     'Kako Holo Interaction povezuje događaje?', 'Koji je posao Holo Interaction?', 'Zašto postoji Holo Interaction?',
     'Ko poštuje smanjeno kretanje animacija?', 'Da li Holo Interaction znači fizičku holografiju?'],
    ['What does Holo Interaction do?', 'Explain the Holo Interaction pillar.', 'Who renders the application interface?',
     'How does Holo Interaction connect events?', 'What is the role of Holo Interaction?',
     'Why is Holo Interaction needed?', 'Does Holo Interaction mean physical holography?'],
    ['Kako Holo Interaction upravlja prikazom?', 'Za šta je odgovoran stub Holo Interaction?'],
    ['Which responsibility belongs to Holo Interaction?']),

topic('fallback_executor', 'docs/CLEA-CORE.md;docs/CLEA-AI-EXPERIMENT.md',
    'Fallback Executor koristi unaprijed dozvoljenu alternativu. Kada cache nije dostupan, podržani proračun može se ponovo stvarno izvršiti.',
    'Fallback Executor uses an explicitly permitted alternative. When cache is unavailable, a supported calculation can actually execute again.',
    ['Šta radi Fallback Executor?', 'Objasni stub Fallback Executor.', 'Ko koristi dozvoljenu alternativu?',
     'Kako Fallback Executor bira rezervni postupak?', 'Koji je posao Fallback Executor?', 'Zašto postoji Fallback Executor?',
     'Šta radi Fallback Executor kad cache zakaže?', 'Da li Fallback Executor izmišlja rezultat?'],
    ['What does Fallback Executor do?', 'Explain the Fallback Executor pillar.', 'Who uses a permitted alternative?',
     'How does Fallback Executor choose an alternative?', 'What is the role of Fallback Executor?',
     'Why is Fallback Executor needed?', 'What happens when cache is unavailable?'],
    ['Kako Fallback Executor nastavlja podržani rad?', 'Za šta je odgovoran stub Fallback Executor?'],
    ['Which responsibility belongs to Fallback Executor?']),

topic('vision_q', 'docs/CLEA-CORE.md;docs/CLEA-AI-EXPERIMENT.md',
    'Vision Q prikazuje stvarne tragove izvršavanja, greške i izmjerene brojače. Objašnjenja moraju odgovarati zabilježenim događajima.',
    'Vision Q exposes real execution traces, errors and measured counters. Explanations must correspond to recorded events.',
    ['Šta radi Vision Q?', 'Objasni stub Vision Q.', 'Ko prikazuje stvarne tragove izvršavanja?',
     'Kako Vision Q objašnjava događaje?', 'Koji je posao Vision Q?', 'Zašto postoji Vision Q?',
     'Ko prikazuje izmjerene brojače i greške?', 'Da li Vision Q izmišlja dijagnostiku?'],
    ['What does Vision Q do?', 'Explain the Vision Q pillar.', 'Who exposes real execution traces?',
     'How does Vision Q explain events?', 'What is the role of Vision Q?',
     'Why is Vision Q needed?', 'Does Vision Q invent diagnostics?'],
    ['Kako Vision Q povezuje objašnjenje i događaj?', 'Za šta je odgovoran stub Vision Q?'],
    ['Which responsibility belongs to Vision Q?']),

topic('bil_language', 'docs/BIL-CORE.md;docs/BIL-DERIVE.md',
    'BIL je tipizirani CLEA jezik za stanje, funkcije, događaje i interfejs. Provjera tipova prethodi izvršavanju podržanog programa.',
    'BIL is the typed CLEA language for state, functions, events and interfaces. Type checking precedes supported program execution.',
    ['Šta je BIL?', 'Objasni CLEA programski jezik.', 'Čemu služi BIL jezik?', 'Da li BIL provjerava tipove?',
     'Može li BIL opisati događaje i stanje?', 'Šta programer piše u BIL jeziku?', 'Koji je jezik CLEA aplikacija?',
     'Kako BIL povezuje funkcije i interfejs?'],
    ['What is BIL?', 'Explain the CLEA programming language.', 'What is BIL used for?', 'Does BIL check types?',
     'Can BIL describe events and state?', 'Which language describes CLEA applications?', 'How does BIL connect functions and interfaces?'],
    ['Kako BIL jezik opisuje aplikacijsku logiku?', 'Zašto BIL provjerava tipove prije rada?'],
    ['How does the BIL language describe application logic?']),

topic('compiler', 'docs/CLEA-CORE.md;web/workbench/bil-compiler.js',
    'Kompajler pretvara BIL izvor u provjereni međukod. Koristi tokenizaciju, parser, provjeru tipova i izvorne lokacije grešaka.',
    'The compiler turns BIL source into checked intermediate code. It uses tokenization, parsing, type checking and source error locations.',
    ['Šta radi BIL kompajler?', 'Kako BIL izvor postaje međukod?', 'Objasni kompajliranje BIL programa.',
     'Ko provjerava sintaksu BIL koda?', 'Kako kompajler pronalazi grešku u izvoru?', 'Da li kompajler koristi parser?',
     'Čemu služi BIL međukod?', 'Ko pretvara izvorni kod u IR?'],
    ['What does the BIL compiler do?', 'How does BIL source become intermediate code?', 'Explain BIL compilation.',
     'Who checks BIL syntax?', 'How does the compiler locate source errors?', 'Does the compiler use a parser?',
     'Who turns source code into IR?'],
    ['Kako kompajler provjerava izvorni BIL program?', 'Koji postupak pretvara BIL u provjereni IR?'],
    ['Which process checks BIL source before producing IR?']),

topic('clea_core', 'docs/CLEA-CORE.md;web/workbench/clea-core.js',
    'CLEA Core dijeli provjereni kompajler i izvršnu semantiku između hostova. Sam ne dodjeljuje mrežni, sistemski ili hardverski pristup.',
    'CLEA Core shares the checked compiler and execution semantics across hosts. It does not grant network, system or hardware access itself.',
    ['Šta je CLEA Core?', 'Objasni zajedničko CLEA jezgro.', 'Čemu služi Core izvršno jezgro?',
     'Da li Core direktno pristupa hardveru?', 'Ko dijeli izvršnu semantiku između hostova?', 'Kako CLEA Core povezuje izvršavanje?',
     'Da li Core sam daje mrežni pristup?', 'Zašto Studio i Runtime koriste isti Core?'],
    ['What is CLEA Core?', 'Explain the shared CLEA execution core.', 'What is the execution core used for?',
     'Does Core access hardware directly?', 'Who shares execution semantics across hosts?',
     'Does Core grant network access itself?', 'Why do Studio and Runtime share Core?'],
    ['Koja je uloga zajedničkog CLEA Core jezgra?', 'Kako Core odvaja logiku od hardverskog hosta?'],
    ['What is the responsibility of the shared CLEA Core?']),

topic('studio', 'docs/CLEA-AI-EXPERIMENT.md;web/workbench/studio.js',
    'CLEA Studio uređuje projekt, BIL kod i podržane vizuelne elemente. Prikaz i pokretanje koriste postojeći provjereni Core i Runtime.',
    'CLEA Studio edits projects, BIL code and supported visual elements. Preview and execution use the existing checked Core and Runtime.',
    ['Šta je CLEA Studio?', 'Čemu služi Studio?', 'Gdje uređujem BIL aplikaciju?', 'Mogu li uređivati kod u Studiju?',
     'Kako Studio prikazuje aplikaciju?', 'Ko uređuje vizuelne elemente projekta?', 'Da li Studio koristi stvarni Runtime?',
     'Gdje povezujem kod i vizuelni prikaz?'],
    ['What is CLEA Studio?', 'What is Studio used for?', 'Where can I edit a BIL application?',
     'Can I edit code in Studio?', 'How does Studio preview an application?', 'Who edits visual project elements?',
     'Does Studio use the real Runtime?'],
    ['Kako u Studiju uređujem kod i prikaz?', 'Koji alat povezuje uređivanje projekta i pokretanje?'],
    ['Which tool connects project editing and application preview?']),

topic('runtime_package', 'docs/CLEA-CORE.md;docs/CLEA-AI-EXPERIMENT.md;web/workbench/package.js',
    'Kompatibilni Runtime provjerava i pokreće CLEA paket. Datoteka clea7 sadrži aplikacijski ugovor i zahtijeva podržani host.',
    'A compatible Runtime validates and runs a CLEA package. A clea7 file contains the application contract and requires a supported host.',
    ['Kako pokrećem clea7 paket?', 'Šta radi CLEA Runtime?', 'Da li clea7 datoteka treba Runtime?',
     'Može li svaka platforma sama otvoriti CLEA paket?', 'Ko provjerava paket prije pokretanja?', 'Šta sadrži clea7 datoteka?',
     'Da li je CLEA paket univerzalni OS program?', 'Kako Runtime koristi kompatibilni host?'],
    ['How do I run a clea7 package?', 'What does CLEA Runtime do?', 'Does a clea7 file require Runtime?',
     'Can every platform directly open a CLEA package?', 'Who checks a package before execution?',
     'What does a clea7 file contain?', 'Is a CLEA package a universal operating system executable?'],
    ['Šta je potrebno za izvršavanje clea7 datoteke?', 'Kako Runtime provjerava kompatibilnost paketa?'],
    ['What is required to execute a clea7 application package?']),

topic('sdk', 'README.md;docs/CLEA-CORE.md;clea7/__main__.py',
    'CLEA SDK može kreirati, provjeriti, testirati i zapakovati podržani projekt. Koristi isti BIL kompajler i ugovore kompatibilnosti.',
    'The CLEA SDK can create, check, test and package supported projects. It uses the same BIL compiler and compatibility contracts.',
    ['Šta radi CLEA SDK?', 'Čemu služi razvojni SDK?', 'Kako provjerim projekt kroz SDK?', 'Može li SDK testirati projekt?',
     'Ko zapakuje podržani CLEA projekt?', 'Da li SDK koristi isti kompajler?', 'Kako SDK pomaže programeru?',
     'Koji alat kreira i provjerava projekt?'],
    ['What does CLEA SDK do?', 'What is the development SDK used for?', 'How can SDK check a project?',
     'Can SDK test a project?', 'Who packages supported CLEA projects?', 'Does SDK use the same compiler?',
     'How does SDK help a developer?'],
    ['Koje projektne korake podržava CLEA SDK?', 'Kako SDK provjerava podržani projekt prije pakovanja?'],
    ['Which project workflow steps does the CLEA SDK support?']),

topic('working_cache', 'docs/WORKING-CACHE.md;web/workbench/working-cache.js',
    'Radni cache čuva ograničene rezultate čistih proračuna uz tačne zavisnosti. Ne zamjenjuje korisničko stanje i ne stvara dodatni RAM.',
    'The working cache retains bounded pure calculation results with exact dependencies. It does not replace user state or create extra RAM.',
    ['Šta radi radni cache?', 'Kako CLEA koristi radni cache?', 'Da li cache stvara dodatni RAM?',
     'Da li cache vraća staro stanje korisnika?', 'Šta čuva cache čistih proračuna?', 'Zašto cache provjerava zavisnosti?',
     'Može li radni cache biti neograničen?', 'Da li cache garantuje ubrzanje svakog zadatka?'],
    ['What does the working cache do?', 'How does CLEA use working cache?', 'Does cache create extra RAM?',
     'Does cache replace current user state?', 'What does the pure calculation cache retain?',
     'Why does cache check dependencies?', 'Does cache guarantee faster execution for every task?'],
    ['Kako radni cache čuva rezultate bez vraćanja starog stanja?', 'Da li radni cache povećava fizičku memoriju?'],
    ['How can working cache reuse results without replacing current state?']),

topic('caci', 'docs/CLEA-AI-EXPERIMENT.md;web/workbench/caci.js',
    'CACI odvaja RAM cache i opcionalni lokalni cache od projekata. Provjerava integritet i verziju, a kvar vraća ponovno računanje.',
    'CACI separates RAM cache and optional local cache from projects. It checks integrity and version, and failures trigger recomputation.',
    ['Šta je CACI?', 'Kako CACI čuva projektni cache?', 'Da li CACI odvaja cache od projekata?',
     'Šta radi CACI kada cache nije dostupan?', 'Da li CACI provjerava integritet?', 'Kako CACI koristi lokalnu pohranu?',
     'Zašto CACI prati verziju podataka?', 'Briše li čišćenje CACI cachea moje projekte?'],
    ['What is CACI?', 'How does CACI retain project cache?', 'Does CACI separate cache from projects?',
     'What happens when CACI cache is unavailable?', 'Does CACI check integrity?',
     'How does CACI use local storage?', 'Does clearing CACI cache delete my projects?'],
    ['Kako CACI provjerava lokalne zadržane podatke?', 'Šta CACI radi kad pohrana cachea zakaže?'],
    ['How does CACI recover from unavailable cached data?']),

topic('offline_privacy', 'docs/CLEA-AI-EXPERIMENT.md;PRIVACY.md',
    'Podržani lokalni CLEA zadaci ne trebaju vanjski AI API. Trajno čuvanje razgovora treba biti jasno, opcionalno i pod kontrolom korisnika.',
    'Supported local CLEA tasks need no external AI API. Persistent conversation storage must be clear, optional and controlled by the user.',
    ['Treba li lokalni CLEA AI vanjski API?', 'Kako CLEA štiti privatnost razgovora?', 'Da li razgovor mora ići na server?',
     'Da li je trajno čuvanje razgovora obavezno?', 'Ko kontroliše lokalne razgovore?', 'Može li podržani CLEA zadatak raditi lokalno?',
     'Da li trebam API ključ za lokalni eksperiment?', 'Kako se upravlja čuvanjem razgovora?'],
    ['Does local CLEA AI require an external API?', 'How should CLEA protect conversation privacy?',
     'Must the conversation go to a server?', 'Is persistent conversation storage mandatory?',
     'Who controls local conversations?', 'Can supported CLEA tasks run locally?', 'Do I need an API key for the local experiment?'],
    ['Može li lokalni razgovor raditi bez vanjskog API ključa?', 'Ko treba kontrolisati trajno čuvanje razgovora?'],
    ['Who should control persistent storage of local conversations?']),

topic('permissions', 'docs/CLEA-CORE.md;docs/CLEA-AI-EXPERIMENT.md',
    'Mogućnost nije automatska dozvola. Runtime provjerava podršku i odobrenje; AI ne smije sam sebi dodijeliti pristup datotekama, mreži ili senzorima.',
    'A capability is not automatic permission. Runtime checks support and consent; AI cannot grant itself file, network or sensor access.',
    ['Kako CLEA provjerava dozvole?', 'Može li AI sam sebi dati dozvolu?', 'Da li postojanje kamere daje aplikaciji pristup?',
     'Ko provjerava pristup senzorima?', 'Da li mrežni pristup traži odobrenje?', 'Je li mogućnost isto što i dozvola?',
     'Kako Runtime kontroliše pristup datotekama?', 'Može li AI zaobići sigurnosne granice?'],
    ['How does CLEA check permissions?', 'Can AI grant itself permission?', 'Does having a camera grant application access?',
     'Who checks sensor access?', 'Does network access require consent?', 'Is a capability the same as permission?',
     'Can AI bypass security boundaries?'],
    ['Da li Runtime mora provjeriti mogućnost i dozvolu?', 'Može li model sam odobriti pristup uređaju?'],
    ['Must Runtime check both capability support and permission?']),

topic('shadow_replay', 'docs/CLEA-CORE.md;docs/WORKING-CACHE.md',
    'SHADOW ispituje alternativu u odvojenom stanju. REPLAY ponavlja podržane zabilježene događaje; neizvjesni vanjski efekti nisu proizvoljno ponovljivi.',
    'SHADOW tests an alternative in separate state. REPLAY repeats supported recorded events; uncertain external effects are not freely replayable.',
    ['Šta rade SHADOW i REPLAY?', 'Kako SHADOW ispituje alternativu?', 'Može li REPLAY ponoviti svaki vanjski efekat?',
     'Da li SHADOW mijenja žive podatke?', 'Čemu služi ponavljanje zabilježenog događaja?', 'Objasni razliku između SHADOW i REPLAY.',
     'Kako testiram alternativu bez promjene živog stanja?', 'Da li su neizvjesne vanjske radnje ponovljive?'],
    ['What do SHADOW and REPLAY do?', 'How does SHADOW test an alternative?', 'Can REPLAY repeat every external effect?',
     'Does SHADOW change live data?', 'What is recorded event replay used for?',
     'Explain the difference between SHADOW and REPLAY.', 'How can I test an alternative without changing live state?'],
    ['Kako SHADOW odvaja test od živog izvršavanja?', 'Koje događaje REPLAY smije ponoviti?'],
    ['Which recorded operations may REPLAY safely repeat?']),
]


def normalized(text):
    return re.sub(r'\s+', ' ', text.casefold()).strip()


def build():
    train = [row for item in TOPICS for row in item['train']]
    heldout = [row for item in TOPICS for row in item['heldout']]
    assert len(TOPICS) == 20 and len(train) == 300 and len(heldout) == 60
    questions = [normalized(row['question']) for row in train + heldout]
    assert len(questions) == len(set(questions)), 'Question overlap or duplicate.'
    # Constrain Unicode word/punctuation tokens for a genuinely small decoder.
    token = re.compile(r'\w+|[^\w\s]', re.UNICODE)
    for row in train + heldout:
        assert len(token.findall(row['question'])) <= 48, row
        assert len(token.findall(row['answer'])) <= 48, row
    return {
        'format': 'clea.conversation.corpus/1', 'version': '0.1.0',
        'purpose': 'Original bounded bilingual CLEA knowledge conversations; not a general language corpus.',
        'provenance': {
            'owner': 'Brzo i Lokalno', 'created': '2026-11-03',
            'method': 'Original authored concise summaries and synthetic questions checked against owner project documentation and code.',
            'sourceRoot': 'Existing BL-Clea7-by-brzoilokalno development repository at Core0.18 / localAI0.19.',
            'thirdPartyTextIncluded': False, 'userConversationsIncluded': False,
            'internetScraping': False, 'externalModelOutputsIncluded': False,
            'sensitiveUserDataIncluded': False,
        },
        'license': {
            'status': 'Owner-controlled original corpus; existing project distribution status is unchanged.',
            'copyright': 'Copyright 2026 Brzo i Lokalno for original corpus material.',
            'newPublicLicenseGranted': False,
            'note': 'Training is authorized within the owner project. Free access is not an automatic open-source licence grant.',
        },
        'splitPolicy': 'Fixed disjoint question prompts authored before training. Heldout prompts never select vocabulary or update weights. Stable topic answers occur in training, so this measures paraphrase-conditioned generation, not unseen-fact reasoning.',
        'evaluationLimits': [
            'Small synthetic expert-domain dataset; results do not establish general intelligence or broad factual knowledge.',
            'Heldout answers share topic facts with training; exact generated answer accuracy measures task-conditioned generation, not discovery of new facts.',
            'Source references support dataset provenance; generated answers alone do not prove factual grounding or calibrated uncertainty.',
            'No claim of world-first architecture, legal clearance or universal device support.',
        ],
        'topics': [{key: value for key, value in item.items() if key not in ('train', 'heldout')} for item in TOPICS],
        'train': train, 'heldout': heldout,
    }


if __name__ == '__main__':
    corpus = build()
    raw = (json.dumps(corpus, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    path = ROOT/'clea-conversation-v1.json'
    path.write_bytes(raw)
    print(json.dumps({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
                      'topics': len(corpus['topics']), 'train': len(corpus['train']),
                      'heldout': len(corpus['heldout']), 'bytes': len(raw)}, indent=2))
