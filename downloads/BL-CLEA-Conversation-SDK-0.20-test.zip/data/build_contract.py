"""Source-linked canonical factual guard data, separate from neural training.

Only training prompts are supplied as routing examples. Heldout questions are
never included in retrieval/routing features. Canonical factual answers are
known training targets; their use is a safety guard, not a neural success claim.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
ALIASES = {
    'greeting': ['zdravo', 'pozdrav', 'ćao', 'predstavi', 'ime', 'zoveš', 'hello', 'hi', 'introduce', 'name'],
    'scope': ['znanje', 'sve', 'ograničenja', 'granice', 'ekspert', 'world', 'knowledge', 'everything', 'limits', 'expert'],
    'core_ai_manager': ['core ai manager', 'zadaci', 'rokovi', 'resursi', 'tasks', 'deadlines', 'resources'],
    'link_bridge_elite': ['link bridge elite', 'povezivanje', 'ugovori', 'komponente', 'contracts', 'connects', 'bridge'],
    'expansion_q': ['expansion q', 'proširenja', 'registar', 'operacije', 'extensions', 'registry', 'operations'],
    'adaptive_recovery': ['adaptive recovery', 'oporavak', 'transakcije', 'greške', 'rollback', 'failure', 'transactions'],
    'holo_interaction': ['holo interaction', 'interfejs', 'prikaz', 'animacije', 'interface', 'render', 'animations'],
    'fallback_executor': ['fallback executor', 'alternativa', 'rezervni', 'alternative', 'fallback'],
    'vision_q': ['vision q', 'dijagnostika', 'tragovi', 'brojači', 'diagnostics', 'traces', 'counters'],
    'bil_language': ['bil', 'programski jezik', 'tipovi', 'language', 'types', 'programming'],
    'compiler': ['kompajler', 'kompajliranje', 'parser', 'sintaksa', 'međukod', 'compiler', 'compilation', 'syntax', 'ir'],
    'clea_core': ['clea core', 'jezgro', 'host', 'semantika', 'core', 'semantics'],
    'studio': ['studio', 'uređivanje', 'editor', 'vizuelni', 'edit', 'preview', 'visual'],
    'runtime_package': ['runtime', 'paket', 'clea7', 'kompatibilnost', 'package', 'compatible'],
    'sdk': ['sdk', 'razvojni alat', 'testirati', 'zapakovati', 'development', 'project', 'package'],
    'working_cache': ['radni cache', 'čisti proračun', 'ram', 'memorija', 'zavisnosti', 'working cache', 'pure', 'dependencies'],
    'caci': ['caci', 'projektni cache', 'integritet', 'verzija', 'indexeddb', 'integrity', 'version'],
    'offline_privacy': ['privatnost', 'lokalno', 'razgovor', 'offline', 'privacy', 'conversation', 'api'],
    'permissions': ['dozvole', 'odobrenje', 'senzori', 'pristup', 'permission', 'consent', 'sensor', 'access'],
    'shadow_replay': ['shadow', 'replay', 'živo stanje', 'zabilježeni događaj', 'live state', 'recorded event'],
}
RELATED = {
    'greeting': ['scope', 'studio'], 'scope': ['bil_language', 'offline_privacy'],
    'core_ai_manager': ['fallback_executor', 'vision_q'], 'link_bridge_elite': ['clea_core', 'permissions'],
    'expansion_q': ['permissions', 'link_bridge_elite'], 'adaptive_recovery': ['shadow_replay', 'fallback_executor'],
    'holo_interaction': ['studio', 'bil_language'], 'fallback_executor': ['working_cache', 'adaptive_recovery'],
    'vision_q': ['shadow_replay', 'clea_core'], 'bil_language': ['compiler', 'studio'],
    'compiler': ['bil_language', 'clea_core'], 'clea_core': ['runtime_package', 'permissions'],
    'studio': ['sdk', 'bil_language'], 'runtime_package': ['sdk', 'permissions'],
    'sdk': ['studio', 'runtime_package'], 'working_cache': ['caci', 'adaptive_recovery'],
    'caci': ['working_cache', 'offline_privacy'], 'offline_privacy': ['permissions', 'caci'],
    'permissions': ['link_bridge_elite', 'runtime_package'], 'shadow_replay': ['vision_q', 'adaptive_recovery'],
}


def build():
    raw = (ROOT/'clea-conversation-v1.json').read_bytes()
    corpus = json.loads(raw)
    topics = []
    for item in corpus['topics']:
        identifier = item['id']
        topics.append({
            'id': identifier, 'answers': item['fact'],
            'sources': item['source'].split(';'),
            'aliases': ALIASES[identifier], 'related': RELATED[identifier],
            'routingExamples': [{'text': row['question'], 'language': row['language']}
                                for row in corpus['train'] if row['topic'] == identifier],
        })
    assert set(ALIASES) == {row['id'] for row in topics}
    assert set(RELATED) == set(ALIASES)
    return {
        'format': 'clea.conversation.knowledge-contract/1', 'version': '0.1.0',
        'corpusSha256': hashlib.sha256(raw).hexdigest(),
        'role': 'Explicit original factual guard and disclosed lexical routing; not learned neural weights.',
        'heldoutPromptsIncluded': False,
        'topics': topics,
        'safety': {
            'allowAutomaticHostActions': False, 'allowClaimingGeneralKnowledge': False,
            'markFallbackAsNeural': False,
            'note': 'When generated text is rejected, any canonical fallback must be labelled as a grounded fallback, not successful neural generation.',
        },
    }


if __name__ == '__main__':
    result = build()
    raw = (json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode()
    path = ROOT/'clea-conversation-contract-v1.json'
    path.write_bytes(raw)
    print(json.dumps({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
                      'topics': len(result['topics']), 'bytes': len(raw)}, indent=2))
