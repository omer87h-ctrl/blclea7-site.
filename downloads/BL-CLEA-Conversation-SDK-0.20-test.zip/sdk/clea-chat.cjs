'use strict';
/* Original offline CLEA conversation SDK, by Brzo i Lokalno.
 * The original model/corpus retain their declared project notices and licence.
 * Loads fixed trusted platform files; user questions remain bounded data.
 * No inference server, API key, downloaded model, telemetry or dependency.
 */
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const {webcrypto,createHash}=require('node:crypto');
const FORMAT='clea7.chat.sdk/1',ROOT=path.resolve(__dirname,'..');
const ASSETS=Object.freeze([
 'runtime.js','workbench/living.js','workbench/bil-compiler.js',
 'workbench/bil-runtime.js','workbench/working-cache.js','workbench/clea-core.js',
 'workbench/format.js','workbench/review.js','workbench/caci.js','workbench/chat/assets.js',
 'workbench/chat/neural.js','workbench/chat/runtime.js'
]);
const plain=value=>JSON.parse(JSON.stringify(value));
function fault(code,message){const error=new Error(message);error.code=code;return error;}
function sha(bytes){return createHash('sha256').update(bytes).digest('hex');}
function readFile(webRoot,name,maximum){
 if(typeof name!=='string'||name.includes('\\')||name.split('/').some(part=>!part||part==='.'||part==='..'))throw fault('SDKAsset','Invalid fixed SDK asset path.');
 const target=path.join(webRoot,name);let stat,real;
 try{stat=fs.lstatSync(target);real=fs.realpathSync(target);}catch{throw fault('SDKAsset','Required SDK asset is unavailable: '+name);}
 if(stat.isSymbolicLink()||!stat.isFile()||!real.startsWith(webRoot+path.sep)||stat.size<1||stat.size>maximum)throw fault('SDKAsset','Required SDK asset is unsafe or exceeds its budget: '+name);
 const data=fs.readFileSync(target);if(data.length!==stat.size||data.length>maximum)throw fault('SDKAsset','SDK asset changed while reading: '+name);return data;
}
function jsonAsset(webRoot,name,maximum,expected){
 const bytes=readFile(webRoot,name,maximum);
 if(expected&&(bytes.length!==expected.bytes||sha(bytes)!==expected.sha256))throw fault('SDKIntegrity','SDK data integrity differs: '+name);
 try{return {value:JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)),bytes:bytes.length,sha256:sha(bytes)};}catch(error){if(error.code==='SDKIntegrity')throw error;throw fault('SDKAsset','SDK asset has invalid JSON or UTF-8: '+name);}
}
async function createLocal(options={}){
 if(!options||typeof options!=='object'||Array.isArray(options)||Object.keys(options).some(key=>key!=='webRoot'))throw fault('SDKOptions','Use only an optional trusted webRoot directory.');
 let webRoot;try{webRoot=fs.realpathSync(options.webRoot||path.join(ROOT,'web'));}catch{throw fault('SDKAsset','The SDK browser/Core asset directory is unavailable.');}
 const source={crypto:webcrypto,performance,TextEncoder,TextDecoder,URL,Blob,AbortController,Date,setTimeout,clearTimeout,console,
  atob:globalThis.atob||((text)=>Buffer.from(text,'base64').toString('binary')),
  btoa:globalThis.btoa||((text)=>Buffer.from(text,'binary').toString('base64'))};
 source.globalThis=source;
 // This context is a host boundary for reviewed platform JavaScript, not an OS
 // sandbox for arbitrary hostile scripts. No user/AI text selects loaded code.
 const context=vm.createContext(source,{codeGeneration:{strings:false,wasm:false}}),sources=[];
 for(const name of ASSETS){const bytes=readFile(webRoot,name,262144);sources.push({path:name,bytes:bytes.length,sha256:sha(bytes)});vm.runInContext(bytes.toString('utf8'),context,{filename:'CLEA-SDK/'+name,timeout:1000});}
 const manifestData=jsonAsset(webRoot,'workbench/chat/manifest.json',16384),manifest=source.CLEA7ChatAssets.manifest(manifestData.value);
 if(!Number.isSafeInteger(manifest.training?.parameterCount)||manifest.training.parameterCount<1||manifest.training.parameterCount>500000)throw fault('SDKContract','The model manifest has invalid parameter metadata.');
 const modelData=jsonAsset(webRoot,'workbench/chat/'+manifest.model.path,2097152,manifest.model);
 const knowledgeData=jsonAsset(webRoot,'workbench/chat/'+manifest.knowledge.path,131072,manifest.knowledge);
 const model=source.CLEA7NeuralChat.create(modelData.value);await model.verify();
 let controller=null,closed=false;
 const transport={initialize:async()=>model.describe(),generate:async(question,settings)=>{controller=new AbortController();try{return await model.generate(question,{...settings,signal:controller.signal});}finally{controller=null;}},cancel(){controller?.abort();},close(){controller?.abort();}};
 const runtime=source.CLEA7Chat.create({manifest,knowledge:knowledgeData.value,transport});
 try{await runtime.initialize();}catch(error){runtime.close();throw error;}
 const contract=source.CLEA7Core.check(source.CLEA7Chat.POLICY,{id:'sdk_chat_policy',name:'SDK conversation policy'});
 async function validate(){
  if(closed)throw fault('Closed','The local SDK Runtime is closed.');await model.verify();
  // Execute the same actual BIL policy rather than treating UI/module presence
  // as proof that the execution Core works.
  const compiled=source.CLEA7Core.compile(source.CLEA7Chat.POLICY,{id:'sdk_chat_validation',name:'SDK validation'});
  const initial=await source.CLEA7Core.execute(compiled.ir,'main',compiled.application.state);
  initial.state.bilValues.promptChars=3;initial.state.bilValues.turns=0;initial.state.bilValues.outputLimit=48;
  const result=await source.CLEA7Core.execute(compiled.ir,'check',initial.state);
  if(result.state.bilValues.approved!==true)throw fault('SDKContract','The authoritative BIL policy did not approve its valid probe.');
  return {format:FORMAT,valid:true,core:source.CLEA7Core.FORMAT,coreVersion:source.CLEA7Core.VERSION,modelFingerprint:model.describe().modelFingerprint,
   integrity:{manifest:{bytes:manifestData.bytes,sha256:manifestData.sha256},model:{bytes:modelData.bytes,sha256:modelData.sha256},knowledge:{bytes:knowledgeData.bytes,sha256:knowledgeData.sha256}},
   policy:{checked:contract.valid===true,executed:true,instructions:result.instructions},sources:plain(sources),scope:'Verified loaded local assets, original model parameters and actual BIL/Core policy; no native platform proof.'};
 }
 function info(){if(closed)throw fault('Closed','The local SDK Runtime is closed.');return {format:FORMAT,core:source.CLEA7Core.FORMAT,coreVersion:source.CLEA7Core.VERSION,
  executionHost:'node-cpu-in-process',model:plain(model.describe()),privacy:{inferenceNetwork:false,externalModel:false,telemetry:false,persistentConversation:false},
  limits:plain(manifest.limits),scope:'Original small CLEA-domain conversational model; not a general or frontier model. Node is not an OS sandbox.'};}
 return Object.freeze({FORMAT,ask:async(question,settings)=>plain(await runtime.ask(question,settings)),validate,info,
  cancel:()=>runtime.cancel(),clear:()=>runtime.clear(),clearCache:()=>runtime.clearCache(),close(){if(closed)return;closed=true;runtime.close();},
  get history(){return plain(runtime.history);},get events(){return plain(runtime.events);},get cacheStats(){return plain(runtime.cacheStats);},get busy(){return runtime.busy;}});
}
function argumentsFor(args){
 const [command,...rest]=args;if(!['ask','info','validate'].includes(command))throw fault('Usage','Use ask "question" [--language bs|en] [--no-cache], info or validate.');
 if(command!=='ask'){if(rest.length)throw fault('Usage',command+' takes no arguments.');return {command};}
 const question=rest.shift();if(typeof question!=='string'||!question.trim()||question.startsWith('--')||question.length>1200)throw fault('Usage','ask requires one quoted question of 1–1200 characters.');
 let language='bs',cacheEnabled=true;const seen=new Set();
 for(let i=0;i<rest.length;i++){
  const option=rest[i];if(seen.has(option))throw fault('Usage','Repeated SDK option: '+option);seen.add(option);
  if(option==='--language'){language=rest[++i];if(!['bs','en'].includes(language))throw fault('Usage','Use --language bs or en.');}
  else if(option==='--no-cache')cacheEnabled=false;
  else throw fault('Usage','Unknown SDK option: '+option);
 }
 return {command,question,language,cacheEnabled};
}
async function main(args=process.argv.slice(2)){
 const request=argumentsFor(args),local=await createLocal();
 try{if(request.command==='info')return local.info();if(request.command==='validate')return await local.validate();const answer=await local.ask(request.question,{language:request.language,cacheEnabled:request.cacheEnabled});return {format:FORMAT,ok:true,answer};}
 finally{local.close();}
}
module.exports=Object.freeze({FORMAT,ASSETS,createLocal,main});
if(require.main===module)main().then(result=>process.stdout.write(JSON.stringify(result)+'\n')).catch(error=>{process.stderr.write(JSON.stringify({format:'clea7.chat.sdk-error/1',ok:false,error:{code:String(error.code||'SDK'),message:String(error.message||'The local SDK operation failed.')}})+'\n');process.exitCode=1;});
