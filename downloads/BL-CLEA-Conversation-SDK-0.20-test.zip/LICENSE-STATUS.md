# Distribution status

Copyright 2026 Brzo i Lokalno, for the original project implementation.

This development package is prepared for the owner's review and testing. A final
public license for the original Studio, runtime and SDK has not been selected by
the owner. It does not change the separate licenses of third-party components.

Before a public release, select the original-code distribution terms, verify the
complete dependency/license inventory, review the name and relevant intellectual
property concerns for target markets. No statement of universal legal clearance,
patent novelty or exclusive trademark ownership is made.

The original reusable design material data, colour palettes and motion presets
are separately granted under MATERIALS-LICENSE.txt (MIT), including use in
commercial applications. That grant covers materialized design content and does
not change the distribution terms of the core implementation or vendor components.
