"""Original bounded conditional neural language model for CLEA, by Brzo i Lokalno.

No external model, network, GPU framework or pretrained weights. A learned
question embedding conditions every autoregressive recurrent decoder step.
NumPy implements forward propagation and explicit BPTT/Adam from scratch.
This is a small domain model, not a general or frontier language model.
"""
from __future__ import annotations
import argparse
import base64
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time
import unicodedata

# These names do not override home or tool configuration. Small matrices perform
# better with bounded BLAS threading, and training remains a local CPU operation.
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SPECIAL = ['<pad>', '<bos>', '<eos>', '<unk>', '<bs>', '<en>']
FORMAT = 'clea7.neural-chat/1'


def tokens(text):
    return re.findall(r'\w+|[^\w\s]', unicodedata.normalize('NFKC', text).lower(), re.UNICODE)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def digest(value):
    return hashlib.sha256((value if isinstance(value, bytes) else canonical(value).encode())).hexdigest()


def detokenize(words):
    text = ' '.join(words)
    text = re.sub(r'\s+([.,!?;:%)])', r'\1', text)
    text = re.sub(r'([(])\s+', r'\1', text)
    return text


def load_corpus(path):
    corpus = json.loads(Path(path).read_text())
    if not isinstance(corpus.get('train'), list) or not isinstance(corpus.get('heldout'), list):
        raise ValueError('Expected explicit original train and heldout splits.')
    seen = set()
    for split in ('train', 'heldout'):
        for row in corpus[split]:
            if set(('question', 'answer', 'topic', 'language')) - set(row):
                raise ValueError('Missing conversation fields.')
            if row['language'] not in ('bs', 'en'):
                raise ValueError('Unsupported explicit language.')
            if not isinstance(row['question'], str) or not isinstance(row['answer'], str):
                raise ValueError('Conversation data must be text.')
            q = ' '.join(tokens(row['question']))
            if not q or q in seen:
                raise ValueError('Duplicate/empty question across splits: '+q)
            seen.add(q)
            if len(tokens(row['question'])) > 47 or len(tokens(row['answer'])) > 47:
                raise ValueError('Question/answer exceeds training sequence budget.')
    return corpus


def prepare(corpus):
    # Heldout text is never used to select vocabulary or fit weights.
    vocabulary = SPECIAL + sorted({token for row in corpus['train']
                                    for text in (row['question'], row['answer'])
                                    for token in tokens(text)} - set(SPECIAL))
    if len(vocabulary) > 2048:
        raise ValueError('Original corpus exceeds the first model vocabulary budget.')
    index = {token: n for n, token in enumerate(vocabulary)}
    def encode(row):
        question = [index['<'+row['language']+'>']] + [index.get(t, 3) for t in tokens(row['question'])]
        answer = [index.get(t, 3) for t in tokens(row['answer'])] + [2]
        return {**row, 'q': question, 'a': answer}
    return vocabulary, [encode(row) for row in corpus['train']], [encode(row) for row in corpus['heldout']]


def initialize(vocab, embedding, hidden, seed):
    rng = np.random.default_rng(seed)
    def random(shape, scale):
        return (rng.normal(size=shape)*scale).astype(np.float32)
    # Q and E are distinct learned question/token embeddings, not lookup answers.
    return {'Q': random((vocab, embedding), .1), 'E': random((vocab, embedding), .1),
            'Wq': random((embedding, hidden), 1/math.sqrt(embedding)),
            'bq': np.zeros(hidden, np.float32),
            'Wx': random((embedding, hidden), 1/math.sqrt(embedding)),
            'Wh': random((hidden, hidden), .5/math.sqrt(hidden)),
            'Wc': random((embedding, hidden), 1/math.sqrt(embedding)),
            'bh': np.zeros(hidden, np.float32),
            'Wo': random((hidden, vocab), .1/math.sqrt(hidden)),
            'bo': np.zeros(vocab, np.float32)}


def batch(rows):
    qlen = max(len(row['q']) for row in rows)
    alen = max(len(row['a']) for row in rows)
    q = np.zeros((len(rows), qlen), np.int32)
    target = np.zeros((len(rows), alen), np.int32)
    mask = np.zeros_like(target, np.float32)
    for i, row in enumerate(rows):
        q[i, :len(row['q'])] = row['q']
        target[i, :len(row['a'])] = row['a']
        mask[i, :len(row['a'])] = 1
    return q, target, mask


def loss_and_gradients(p, rows):
    qids, target, mask = batch(rows)
    qmask = (qids != 0).astype(np.float32)
    qcount = qmask.sum(axis=1, keepdims=True)
    context = (p['Q'][qids]*qmask[..., None]).sum(axis=1)/qcount
    hidden = np.tanh(context@p['Wq']+p['bq'])
    initial = hidden
    states, embeddings, probabilities, previous = [], [], [], []
    input_ids = np.ones(len(rows), np.int32)
    total = max(1, mask.sum())
    loss = 0.
    for t in range(target.shape[1]):
        x = p['E'][input_ids]
        before = hidden
        hidden = np.tanh(x@p['Wx']+before@p['Wh']+context@p['Wc']+p['bh'])
        logits = hidden@p['Wo']+p['bo']
        logits -= logits.max(axis=1, keepdims=True)
        prob = np.exp(logits)
        prob /= prob.sum(axis=1, keepdims=True)
        loss += float((-np.log(np.maximum(prob[np.arange(len(rows)), target[:, t]], 1e-12))*mask[:, t]).sum())
        states.append((before, hidden))
        embeddings.append(x)
        probabilities.append(prob)
        previous.append(input_ids)
        input_ids = target[:, t]
    gradients = {key: np.zeros_like(value) for key, value in p.items()}
    dh = np.zeros_like(hidden)
    dc = np.zeros_like(context)
    for t in range(target.shape[1]-1, -1, -1):
        before, hidden = states[t]
        dy = probabilities[t].copy()
        dy[np.arange(len(rows)), target[:, t]] -= 1
        dy *= (mask[:, t]/total)[:, None]
        gradients['Wo'] += hidden.T@dy
        gradients['bo'] += dy.sum(axis=0)
        dt = (dy@p['Wo'].T+dh)*(1-hidden*hidden)
        gradients['Wx'] += embeddings[t].T@dt
        gradients['Wh'] += before.T@dt
        gradients['Wc'] += context.T@dt
        gradients['bh'] += dt.sum(axis=0)
        np.add.at(gradients['E'], previous[t], dt@p['Wx'].T)
        dh = dt@p['Wh'].T
        dc += dt@p['Wc'].T
    dt = dh*(1-initial*initial)
    gradients['Wq'] += context.T@dt
    gradients['bq'] += dt.sum(axis=0)
    dc += dt@p['Wq'].T
    for t in range(qids.shape[1]):
        np.add.at(gradients['Q'], qids[:, t], dc*(qmask[:, t]/qcount[:, 0])[:, None])
    # PAD is never a semantic word.
    gradients['Q'][0] = 0
    norm = math.sqrt(sum(float(np.square(g, dtype=np.float64).sum()) for g in gradients.values()))
    if norm > 5:
        for g in gradients.values():
            g *= 5/norm
    return loss/float(total), gradients, norm


def decoder_context(p, question):
    context = p['Q'][question].mean(axis=0)
    hidden = np.tanh(context@p['Wq']+p['bq'])
    return context, hidden


def decoder_step(p, context, hidden, previous):
    hidden = np.tanh(p['E'][previous]@p['Wx']+hidden@p['Wh']+context@p['Wc']+p['bh'])
    logits = hidden@p['Wo']+p['bo']
    return hidden, logits


def generate(p, row, maximum=48):
    context, hidden = decoder_context(p, row['q'])
    result = []
    previous = 1
    log_probability = 0.
    for _ in range(maximum):
        hidden, logits = decoder_step(p, context, hidden, previous)
        logits[[0, 1, 3, 4, 5]] = -1e9
        previous = int(np.argmax(logits))
        distribution = np.exp(logits-logits.max())
        distribution /= distribution.sum()
        log_probability += float(np.log(max(1e-12, distribution[previous])))
        result.append(previous)
        if previous == 2:
            break
    return result, log_probability/max(1, len(result))


def evaluation(p, rows, vocabulary, full=False):
    exact = 0
    overlap = 0.
    by_topic = {}
    details = []
    for row in rows:
        output, likelihood = generate(p, row)
        is_exact = output == row['a']
        exact += is_exact
        expected_set, actual_set = set(row['a']), set(output)
        overlap += 2*len(expected_set & actual_set)/max(1, len(expected_set)+len(actual_set))
        stats = by_topic.setdefault(row['topic'], {'examples': 0, 'exact': 0})
        stats['examples'] += 1
        stats['exact'] += is_exact
        if full:
            details.append({'question': row['question'], 'topic': row['topic'], 'language': row['language'],
                            'expected': row['answer'], 'generated': detokenize([vocabulary[i] for i in output if i != 2]),
                            'exactTokens': is_exact, 'meanLogProbability': likelihood,
                            'ended': bool(output and output[-1] == 2)})
    result = {'examples': len(rows), 'exact': exact, 'exactRate': exact/max(1, len(rows)),
              'meanTokenSetF1': overlap/max(1, len(rows)), 'byTopic': by_topic}
    if full:
        result['examplesDetailed'] = details
    return result


def serialize(p):
    result = {}
    for name, value in p.items():
        raw = value.astype('<f4').tobytes()
        result[name] = {'shape': list(value.shape), 'encoding': 'base64-f32le',
                        'data': base64.b64encode(raw).decode(), 'sha256': digest(raw)}
    return result


def finite_difference_check():
    p = initialize(9, 3, 4, 7)
    rows = [{'q': [4, 6, 7], 'a': [7, 8, 2]}, {'q': [5, 8], 'a': [6, 2]}]
    loss, gradients, _ = loss_and_gradients(p, rows)
    checked = []
    for key, index in [('Q', (6, 1)), ('E', (7, 2)), ('Wq', (1, 2)), ('Wh', (2, 1)), ('Wc', (1, 3)), ('Wo', (3, 7)), ('bh', (2,))]:
        before = float(p[key][index])
        eps = .002
        p[key][index] = before+eps
        plus = loss_and_gradients(p, rows)[0]
        p[key][index] = before-eps
        minus = loss_and_gradients(p, rows)[0]
        p[key][index] = before
        numerical = (plus-minus)/(2*eps)
        analytic = float(gradients[key][index])
        if abs(numerical-analytic) > .00015:
            raise AssertionError((key, numerical, analytic))
        checked.append({'weight': key, 'analytic': analytic, 'finiteDifference': numerical})
    return {'loss': loss, 'checks': checked}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus', type=Path, default=ROOT/'data/clea-conversation-v1.json')
    parser.add_argument('--output', type=Path, default=ROOT/'neural/clea-chat-model.json')
    parser.add_argument('--report', type=Path, default=ROOT/'neural/training-report.json')
    parser.add_argument('--steps', type=int, default=1600)
    parser.add_argument('--batch', type=int, default=24)
    parser.add_argument('--embedding', type=int, default=32)
    parser.add_argument('--hidden', type=int, default=96)
    parser.add_argument('--learning-rate', type=float, default=.003)
    parser.add_argument('--seed', type=int, default=7020)
    parser.add_argument('--check-gradients', action='store_true')
    parser.add_argument('--replace', action='store_true')
    args = parser.parse_args()
    if args.check_gradients:
        print(canonical(finite_difference_check()), flush=True)
        return
    if args.output.exists() and not args.replace:
        raise ValueError('Output exists; use a new path or explicit --replace for your own model.')
    if not 1 <= args.steps <= 10000 or not 1 <= args.batch <= 64 or not 8 <= args.hidden <= 192 or not 8 <= args.embedding <= 64:
        raise ValueError('Training configuration exceeds declared resource bounds.')
    started = time.perf_counter()
    corpus = load_corpus(args.corpus)
    vocabulary, training, heldout = prepare(corpus)
    p = initialize(len(vocabulary), args.embedding, args.hidden, args.seed)
    initial_fingerprint = digest(serialize(p))
    initial = evaluation(p, heldout, vocabulary)
    rng = np.random.default_rng(args.seed+1)
    moments = {name: np.zeros_like(value) for name, value in p.items()}
    variances = {name: np.zeros_like(value) for name, value in p.items()}
    losses = []
    for step in range(1, args.steps+1):
        chosen = rng.integers(0, len(training), size=args.batch)
        loss, gradients, norm = loss_and_gradients(p, [training[i] for i in chosen])
        rate = args.learning_rate*(.35+.65*(1-step/args.steps))
        for name, value in p.items():
            g = gradients[name]
            moments[name] = .9*moments[name]+.1*g
            variances[name] = .999*variances[name]+.001*g*g
            value -= rate*(moments[name]/(1-.9**step))/(np.sqrt(variances[name]/(1-.999**step))+1e-8)
        if step == 1 or step % 100 == 0 or step == args.steps:
            item = {'step': step, 'loss': loss, 'gradientNorm': norm,
                    'elapsedSeconds': time.perf_counter()-started}
            losses.append(item)
            print(canonical(item), flush=True)
    final_train = evaluation(p, training, vocabulary)
    final_heldout = evaluation(p, heldout, vocabulary, full=True)
    weights = serialize(p)
    model = {'format': FORMAT, 'version': '0.1.0', 'architecture': 'conditional-tanh-rnn/1',
             'name': 'CLEA Original Conversation Micro',
             'tokenizer': {'kind': 'nfkc-lower-unicode-words-punctuation/1', 'vocabulary': vocabulary,
                           'pad': 0, 'bos': 1, 'eos': 2, 'unk': 3, 'languages': {'bs': 4, 'en': 5}},
             'dimensions': {'vocabulary': len(vocabulary), 'embedding': args.embedding, 'hidden': args.hidden},
             'limits': {'inputCharacters': 1200, 'questionTokens': 48, 'outputTokens': 48},
             'weights': weights,
             'training': {'algorithm': 'manual BPTT with Adam and gradient-norm clipping',
                          'seed': args.seed, 'steps': args.steps, 'batchSize': args.batch,
                          'initialLearningRate': args.learning_rate, 'trainingExamples': len(training),
                          'heldoutExamples': len(heldout), 'corpusSha256': digest(corpus),
                          'initialWeightsSha256': initial_fingerprint,
                          'vocabularyUsesHeldout': False, 'weightUpdatesUseHeldout': False,
                          'externalWeights': False, 'network': False,
                          'parameterCount': sum(value.size for value in p.values())},
             'provenance': corpus.get('provenance'), 'license': corpus.get('license')}
    model['modelFingerprint'] = digest(model)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(model, ensure_ascii=False, separators=(',', ':'))+'\n')
    report = {'format': 'clea7.neural-chat.training/1', 'modelFingerprint': model['modelFingerprint'],
              'corpusSha256': digest(corpus), 'initialHeldout': initial, 'trainedTrain': final_train,
              'trainedHeldout': final_heldout, 'lossHistory': losses,
              'parameterCount': model['training']['parameterCount'],
              'weightBytes': sum(value.nbytes for value in p.values()), 'modelFileBytes': args.output.stat().st_size,
              'elapsedSeconds': time.perf_counter()-started,
              'limits': ['Original small fixed domain corpus, not general language knowledge.',
                         'Exact heldout answer rate is not real-world factual accuracy.',
                         'Model output must pass the separate Runtime evidence/scope policy.']}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    # Independent JS forward test vectors, computed without changing weights.
    vectors = []
    for row in heldout[:4]:
        context, hidden = decoder_context(p, row['q'])
        next_hidden, logits = decoder_step(p, context, hidden, 1)
        generated, _ = generate(p, row)
        vectors.append({'question': row['question'], 'language': row['language'], 'questionIds': row['q'],
                        'context': context.tolist(), 'initialHidden': hidden.tolist(),
                        'nextHidden': next_hidden.tolist(), 'logits': logits.tolist(), 'generatedIds': generated})
    (args.output.parent/'test-vectors.json').write_text(json.dumps({'modelFingerprint': model['modelFingerprint'], 'vectors': vectors}, ensure_ascii=False)+'\n')
    print(canonical({'output': str(args.output), 'report': str(args.report), 'modelBytes': args.output.stat().st_size,
                     'trainExact': final_train['exactRate'], 'heldoutExact': final_heldout['exactRate'],
                     'seconds': time.perf_counter()-started}), flush=True)


if __name__ == '__main__':
    main()
